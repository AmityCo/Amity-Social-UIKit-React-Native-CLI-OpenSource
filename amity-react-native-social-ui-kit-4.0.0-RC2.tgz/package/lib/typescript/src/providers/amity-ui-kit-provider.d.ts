import * as React from 'react';
import { DefaultTheme, type MD3Theme } from 'react-native-paper';
import { IConfigRaw } from '../v4/types/config.interface';
import { IBehaviour } from '../v4/types/behaviour.interface';
export type CusTomTheme = typeof DefaultTheme;
export interface IAmityUIkitProvider {
    userId: string;
    displayName?: string;
    apiKey: string;
    apiRegion?: string;
    apiEndpoint?: string;
    children: any;
    authToken?: string;
    configs?: IConfigRaw;
    behaviour?: IBehaviour;
    fcmToken?: string;
}
export interface CustomColors {
    primary?: string;
    primaryShade1?: string;
    primaryShade2?: string;
    primaryShade3?: string;
    primaryShade4?: string;
    secondary?: string;
    secondaryShade1?: string;
    secondaryShade2?: string;
    secondaryShade3?: string;
    secondaryShade4?: string;
    background?: string;
    backgroundShade1?: string;
    base?: string;
    baseShade1?: string;
    baseShade2?: string;
    baseShade3?: string;
    baseShade4?: string;
    alert?: string;
    live?: string;
}
export interface MyMD3Theme extends MD3Theme {
    colors: MD3Theme['colors'] & CustomColors;
}
export default function AmityUiKitProvider({ userId, displayName, apiKey, apiRegion, apiEndpoint, children, authToken, configs, behaviour, fcmToken, }: IAmityUIkitProvider): React.JSX.Element;
//# sourceMappingURL=amity-ui-kit-provider.d.ts.map