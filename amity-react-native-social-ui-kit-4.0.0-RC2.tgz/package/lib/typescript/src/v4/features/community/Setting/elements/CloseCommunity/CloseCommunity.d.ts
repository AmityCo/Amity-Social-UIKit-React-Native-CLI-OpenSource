import React from 'react';
import { TouchableOpacityProps } from 'react-native';
import { ComponentID, ElementID, PageID } from '~/v4/enum';
type CloseCommunityProps = TouchableOpacityProps & {
    pageId?: PageID;
    componentId?: ComponentID;
    elementId?: ElementID;
};
declare function CloseCommunity({ pageId, componentId, elementId, ...props }: CloseCommunityProps): React.JSX.Element;
export default CloseCommunity;
//# sourceMappingURL=CloseCommunity.d.ts.map