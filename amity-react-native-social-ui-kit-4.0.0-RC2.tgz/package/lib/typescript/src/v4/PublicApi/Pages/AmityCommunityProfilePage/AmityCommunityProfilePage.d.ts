import React from 'react';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { RootStackParamList } from '../../../routes/RouteParamList';
declare const _default: React.MemoExoticComponent<({ route, }: NativeStackScreenProps<RootStackParamList, "CommunityProfilePage">) => React.JSX.Element>;
export default _default;
//# sourceMappingURL=AmityCommunityProfilePage.d.ts.map