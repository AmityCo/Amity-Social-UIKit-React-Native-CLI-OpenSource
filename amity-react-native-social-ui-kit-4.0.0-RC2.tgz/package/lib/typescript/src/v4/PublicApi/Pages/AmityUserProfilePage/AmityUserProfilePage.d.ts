import React from 'react';
import { RootStackParamList } from '~/v4/routes/RouteParamList';
type UserProfilePageProps = RootStackParamList['UserProfile'];
declare function UserProfile({ userId }: UserProfilePageProps): React.JSX.Element;
export default UserProfile;
//# sourceMappingURL=AmityUserProfilePage.d.ts.map