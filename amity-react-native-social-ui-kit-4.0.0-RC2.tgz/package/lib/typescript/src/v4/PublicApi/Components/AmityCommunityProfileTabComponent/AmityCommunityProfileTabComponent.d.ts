import React from 'react';
import { ComponentID, PageID } from '~/v4/enum';
export declare const enum CommunityProfileTab {
    community_feed = "community_feed",
    community_pin = "community_pin",
    community_image_feed = "community_image_feed",
    community_video_feed = "community_video_feed"
}
type AmityCommunityProfileTabComponentProps = {
    pageId?: PageID;
    componentId?: ComponentID;
    currentTab: CommunityProfileTab;
    onTabChange: (tab: CommunityProfileTab) => void;
};
declare const _default: React.NamedExoticComponent<AmityCommunityProfileTabComponentProps>;
export default _default;
//# sourceMappingURL=AmityCommunityProfileTabComponent.d.ts.map