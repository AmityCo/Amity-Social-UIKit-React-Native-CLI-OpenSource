import React from 'react';
import { PageID } from '../../../enum';
export interface AmityCommunityHeaderRef {
    height: number;
}
type AmityCommunityHeaderComponentProps = {
    pageId?: PageID;
    communityId: string;
    isScrolled?: boolean;
    isScrolling?: boolean;
    onHeightChange?: (height: number) => void;
};
declare const _default: React.NamedExoticComponent<AmityCommunityHeaderComponentProps>;
export default _default;
//# sourceMappingURL=AmityCommunityHeaderComponent.d.ts.map