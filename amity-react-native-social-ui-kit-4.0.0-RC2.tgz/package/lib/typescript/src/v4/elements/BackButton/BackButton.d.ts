import React from 'react';
import { TouchableOpacityProps } from 'react-native';
import { XmlProps } from 'react-native-svg';
import { ComponentID, ElementID, PageID } from '~/v4/enum';
type BackButtonProps = TouchableOpacityProps & {
    pageId?: PageID;
    componentId?: ComponentID;
    elementId?: ElementID;
    iconProps?: Pick<XmlProps, 'width' | 'height' | 'color'>;
};
declare function BackButton({ pageId, componentId, elementId, iconProps, ...props }: BackButtonProps): React.JSX.Element;
export default BackButton;
//# sourceMappingURL=BackButton.d.ts.map