import React from 'react';
import { XmlProps } from 'react-native-svg';
import { ComponentID, ElementID, PageID } from '~/v4/enum';
type AnnouncementBadgeProps = {
    pageId?: PageID;
    componentId?: ComponentID;
    elementId?: ElementID;
    iconProps?: Pick<XmlProps, 'width' | 'height' | 'color'>;
};
declare function AnnouncementBadge({ pageId, componentId, elementId, iconProps, }: AnnouncementBadgeProps): React.JSX.Element;
export default AnnouncementBadge;
//# sourceMappingURL=AnnouncementBadge.d.ts.map