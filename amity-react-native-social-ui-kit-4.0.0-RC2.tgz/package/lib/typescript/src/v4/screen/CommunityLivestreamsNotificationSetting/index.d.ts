import React from 'react';
import { RootStackParamList } from '~/v4/routes/RouteParamList';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
type CommunityLivestreamsNotificationSettingProps = NativeStackScreenProps<RootStackParamList, 'CommunityLivestreamsNotificationSetting'>;
declare function CommunityLivestreamsNotificationSetting(_: CommunityLivestreamsNotificationSettingProps): React.JSX.Element;
export default CommunityLivestreamsNotificationSetting;
//# sourceMappingURL=index.d.ts.map