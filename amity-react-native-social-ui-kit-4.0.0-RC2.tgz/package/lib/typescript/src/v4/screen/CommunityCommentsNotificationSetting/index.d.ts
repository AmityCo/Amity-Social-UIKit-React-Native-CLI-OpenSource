import React from 'react';
import { RootStackParamList } from '~/v4/routes/RouteParamList';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
type CommunityCommentsNotificationSettingProps = NativeStackScreenProps<RootStackParamList, 'CommunityCommentsNotificationSetting'>;
declare function CommunityCommentsNotificationSetting(_: CommunityCommentsNotificationSettingProps): React.JSX.Element;
export default CommunityCommentsNotificationSetting;
//# sourceMappingURL=index.d.ts.map