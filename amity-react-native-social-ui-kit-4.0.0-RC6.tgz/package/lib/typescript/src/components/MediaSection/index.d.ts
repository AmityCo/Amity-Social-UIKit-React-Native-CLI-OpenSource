import React from 'react';
interface IMediaSection {
    childrenPosts: string[];
}
declare const _default: React.NamedExoticComponent<IMediaSection>;
export default _default;
//# sourceMappingURL=index.d.ts.map