import React from 'react';
export default function CloseButton({ onPress }: {
    onPress: () => void;
}): React.JSX.Element;
//# sourceMappingURL=index.d.ts.map