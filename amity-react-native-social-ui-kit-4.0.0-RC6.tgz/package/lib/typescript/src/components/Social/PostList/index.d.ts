import React from 'react';
import type { UserInterface } from '../../../types/user.interface';
import { IMentionPosition } from '../../../screens/CreatePost';
export interface IPost {
    postId: string;
    data: Record<string, any>;
    dataType: string | undefined;
    myReactions: string[];
    reactionCount: Record<string, number>;
    commentsCount: number;
    user: UserInterface | undefined;
    creator: Amity.User;
    updatedAt: string | undefined;
    editedAt: string | undefined;
    createdAt: string;
    targetType: string;
    targetId: string;
    childrenPosts: string[];
    mentionees: string[];
    mentionPosition?: IMentionPosition[];
    path: string;
    analytics: Amity.Post<'analytics'>;
}
export interface IPostList {
    onDelete?: (postId: string) => void;
    onChange?: (postDetail: Amity.Post<any>) => void;
    postDetail: Amity.Post<any> & {
        structureType?: string;
    };
    postIndex?: number;
    isGlobalfeed?: boolean;
}
export interface MediaUri {
    uri: string;
}
export interface IVideoPost {
    thumbnailFileId: string;
    videoFileId: {
        original: string;
    };
}
export default function PostList({ postDetail, postIndex, onDelete, isGlobalfeed, }: IPostList): React.JSX.Element;
//# sourceMappingURL=index.d.ts.map