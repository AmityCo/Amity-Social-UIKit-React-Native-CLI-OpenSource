import React from 'react';
import type { UserInterface } from '../../../types/user.interface';
import { IMentionPosition } from '../../../screens/CreatePost';
export interface IComment {
    commentId: string;
    data: Record<string, any>;
    dataType: string | undefined;
    myReactions: string[];
    reactions: Record<string, number>;
    user: UserInterface | undefined;
    updatedAt: string | undefined;
    editedAt: string | undefined;
    createdAt: string;
    childrenComment: string[];
    referenceId: string;
    mentionees?: string[];
    mentionPosition?: IMentionPosition[];
    childrenNumber: number;
}
export interface IReplyCommentList {
    commentId: string;
    commentDetail: IComment;
    onDelete?: (commentId: string) => void;
}
export default function ReplyCommentList({ commentDetail, onDelete, commentId, }: IReplyCommentList): React.JSX.Element;
//# sourceMappingURL=index.d.ts.map