import React from 'react';
import type { UserInterface } from '../../../types/user.interface';
import { IMentionPosition } from '../../../screens/CreatePost';
export interface IComment {
    commentId: string;
    data: Record<string, any>;
    dataType: string | undefined;
    myReactions: string[];
    reactions: Record<string, number>;
    user: UserInterface | undefined;
    updatedAt: string | undefined;
    editedAt: string | undefined;
    createdAt: string;
    childrenComment: string[];
    referenceId: string;
    mentionees?: string[];
    mentionPosition?: IMentionPosition[];
    childrenNumber: number;
}
export interface ICommentList {
    commentDetail: IComment;
    isReplyComment?: boolean;
    onDelete: (commentId: string) => void;
    onClickReply: (user: UserInterface, commentId: string) => void;
}
declare const CommentList: ({ commentDetail, onDelete, onClickReply, }: ICommentList) => React.JSX.Element;
export default CommentList;
//# sourceMappingURL=index.d.ts.map