import React from 'react';
export interface ISearchItem {
    targetId: string;
    targetType: string;
    displayName: string;
    categoryIds?: string[];
    avatarFileId?: string;
    id?: string;
}
export default function SearchItem({ target, onPress, userProfileNavigateEnabled, }: {
    target: ISearchItem;
    onPress?: (target: ISearchItem) => void;
    userProfileNavigateEnabled?: boolean;
}): React.JSX.Element;
//# sourceMappingURL=index.d.ts.map