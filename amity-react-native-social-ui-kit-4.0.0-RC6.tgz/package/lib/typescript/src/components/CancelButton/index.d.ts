import React from 'react';
export default function CancelButton(): React.JSX.Element;
//# sourceMappingURL=index.d.ts.map