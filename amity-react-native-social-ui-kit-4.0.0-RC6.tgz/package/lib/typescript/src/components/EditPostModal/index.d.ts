import React from 'react';
import type { IVideoPost } from '../Social/PostList';
interface IModal {
    visible: boolean;
    userId?: string;
    onClose: () => void;
    onFinishEdit: (postData: {
        text: string;
        mediaUrls: string[] | IVideoPost[];
    }, type: string) => void;
    postDetail: Amity.Post<any> & {
        data?: {
            text?: string;
        };
    };
    videoPostsArr?: IVideoPost[];
    imagePostsArr?: string[];
    privateCommunityId: string | null;
}
declare const _default: React.MemoExoticComponent<({ visible, onClose, postDetail, onFinishEdit, privateCommunityId, }: IModal) => React.JSX.Element>;
export default _default;
//# sourceMappingURL=index.d.ts.map