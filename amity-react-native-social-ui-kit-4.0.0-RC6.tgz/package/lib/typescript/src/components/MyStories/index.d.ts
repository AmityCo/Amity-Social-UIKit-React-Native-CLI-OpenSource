import React from 'react';
export interface IStoryItems {
    communityId: string;
    avatarFileId: string;
    displayName: string;
    isPublic: boolean;
    isOfficial: boolean;
    hasStories: boolean;
}
export default function MyStories(): React.JSX.Element;
//# sourceMappingURL=index.d.ts.map