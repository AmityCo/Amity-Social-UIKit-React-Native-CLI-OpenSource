import React from 'react';
import type { IComment } from '../../v4/PublicApi/Components/AmityPostCommentComponent/CommentListItem/CommentListItem';
interface IModal {
    visible: boolean;
    userId?: string;
    onClose: () => void;
    onFinishEdit: (editText: string) => void;
    commentDetail: IComment;
}
declare const EditCommentModal: ({ visible, onClose, commentDetail, onFinishEdit, }: IModal) => React.JSX.Element;
export default EditCommentModal;
//# sourceMappingURL=index.d.ts.map