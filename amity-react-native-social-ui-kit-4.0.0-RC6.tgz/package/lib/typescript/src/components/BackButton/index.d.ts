import React from 'react';
interface IBackBtn {
    onPress?: () => any;
    goBack?: boolean;
}
export default function BackButton({ onPress, goBack }: IBackBtn): React.JSX.Element;
export {};
//# sourceMappingURL=index.d.ts.map