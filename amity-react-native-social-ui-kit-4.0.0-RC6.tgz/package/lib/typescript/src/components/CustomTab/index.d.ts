import { type ReactElement } from 'react';
import { TabName } from '../../enum/tabNameState';
interface ICustomTab {
    onTabChange: (tabName: TabName) => void;
    tabName: TabName[];
}
declare const CustomTab: ({ tabName, onTabChange }: ICustomTab) => ReactElement;
export default CustomTab;
//# sourceMappingURL=index.d.ts.map