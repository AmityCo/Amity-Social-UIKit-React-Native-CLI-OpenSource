import React from 'react';
interface IBackBtn {
    onPress: () => any;
    isGlobalFeed?: boolean;
}
export default function FloatingButton({ onPress, isGlobalFeed, }: IBackBtn): React.JSX.Element;
export {};
//# sourceMappingURL=index.d.ts.map