import React from 'react';
export default function MyCommunity(): React.JSX.Element;
//# sourceMappingURL=index.d.ts.map