import React from 'react';
import type { UserInterface } from '../../types/user.interface';
interface IModal {
    visible: boolean;
    userId?: string;
    initUserList: UserInterface[];
    onClose: () => void;
    onSelect: (users: UserInterface[]) => void;
    excludeUserList?: UserInterface[];
}
export type SelectUserList = {
    title: string;
    data: UserInterface[];
};
declare const AddMembersModal: ({ visible, onClose, onSelect, initUserList, excludeUserList, }: IModal) => React.JSX.Element;
export default AddMembersModal;
//# sourceMappingURL=index.d.ts.map