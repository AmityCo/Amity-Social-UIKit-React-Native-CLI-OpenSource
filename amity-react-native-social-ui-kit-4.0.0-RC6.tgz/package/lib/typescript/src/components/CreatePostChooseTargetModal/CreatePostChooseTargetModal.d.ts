import React from 'react';
interface IModal {
    visible: boolean;
    userId?: string;
    onClose: () => void;
    onSelect: () => void;
    postType: string;
}
declare const _default: React.MemoExoticComponent<({ visible, onClose, userId, onSelect, postType, }: IModal) => React.JSX.Element>;
export default _default;
//# sourceMappingURL=CreatePostChooseTargetModal.d.ts.map