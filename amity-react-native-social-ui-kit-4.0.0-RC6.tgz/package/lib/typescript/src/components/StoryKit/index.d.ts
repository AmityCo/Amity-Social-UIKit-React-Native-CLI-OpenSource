export * from './src/interfaces';
export declare const AmityStory: {
    ({ data, unPressedBorderColor, pressedBorderColor, unPressedAvatarTextColor, pressedAvatarTextColor, style, onStart, onClose, duration, swipeText, avatarSize, showAvatarText, avatarTextStyle, onStorySeen, renderCloseComponent, renderSwipeUpComponent, renderTextComponent, loadedAnimationBarStyle, unloadedAnimationBarStyle, animationBarContainerStyle, storyUserContainerStyle, storyImageStyle, storyAvatarImageStyle, storyContainerStyle, avatarImageStyle, avatarWrapperStyle, avatarFlatListProps, isCommunityStory, }: import("./src/interfaces").StoryProps): import("react").JSX.Element;
    defaultProps: {
        showAvatarText: boolean;
    };
};
export default AmityStory;
//# sourceMappingURL=index.d.ts.map