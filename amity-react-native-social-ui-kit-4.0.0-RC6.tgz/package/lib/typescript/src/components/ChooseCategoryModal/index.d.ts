import React from 'react';
interface IModal {
    visible: boolean;
    userId?: string;
    onClose: () => void;
    onSelect: (categoryId: string, categoryName: string) => void;
    categoryId?: string;
}
declare const ChooseCategoryModal: ({ visible, onClose, onSelect, categoryId, }: IModal) => React.JSX.Element;
export default ChooseCategoryModal;
//# sourceMappingURL=index.d.ts.map