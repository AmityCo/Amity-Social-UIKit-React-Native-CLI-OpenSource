import React from 'react';
interface ICommunityStories {
    communityId: string;
}
export default function CommunityStories({ communityId }: ICommunityStories): React.JSX.Element;
export {};
//# sourceMappingURL=index.d.ts.map