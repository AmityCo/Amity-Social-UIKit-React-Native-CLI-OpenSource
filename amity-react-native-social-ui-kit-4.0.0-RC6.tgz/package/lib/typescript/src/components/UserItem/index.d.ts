import React from 'react';
import type { UserInterface } from 'src/types/user.interface';
export default function UserItem({ user, isCheckmark, showThreeDot, onPress, onThreeDotTap, hideMenu, }: {
    user: UserInterface;
    isCheckmark?: boolean;
    showThreeDot?: boolean;
    onPress?: (user: UserInterface) => void;
    onThreeDotTap?: (user: UserInterface) => void;
    hideMenu?: boolean;
}): React.JSX.Element;
//# sourceMappingURL=index.d.ts.map