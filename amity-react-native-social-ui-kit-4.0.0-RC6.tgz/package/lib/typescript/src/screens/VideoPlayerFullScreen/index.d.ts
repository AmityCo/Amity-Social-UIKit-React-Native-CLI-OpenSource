import React from 'react';
declare const VideoPlayerFull: () => React.JSX.Element;
export default VideoPlayerFull;
//# sourceMappingURL=index.d.ts.map