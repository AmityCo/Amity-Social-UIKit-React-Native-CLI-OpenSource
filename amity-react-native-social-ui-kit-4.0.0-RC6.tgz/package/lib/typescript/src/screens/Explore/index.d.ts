import * as React from 'react';
export default function Explore(): React.JSX.Element;
//# sourceMappingURL=index.d.ts.map