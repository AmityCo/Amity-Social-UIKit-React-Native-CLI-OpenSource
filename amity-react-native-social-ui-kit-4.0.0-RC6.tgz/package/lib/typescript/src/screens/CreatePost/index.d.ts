import React from 'react';
export interface IDisplayImage {
    url: string;
    fileId: string | undefined;
    fileName: string;
    isUploaded: boolean;
    thumbNail?: string;
}
export interface IMentionPosition {
    index: number;
    type: string;
    userId: string;
    length: number;
    displayName?: string;
}
declare const CreatePost: ({ route }: any) => React.JSX.Element;
export default CreatePost;
//# sourceMappingURL=index.d.ts.map