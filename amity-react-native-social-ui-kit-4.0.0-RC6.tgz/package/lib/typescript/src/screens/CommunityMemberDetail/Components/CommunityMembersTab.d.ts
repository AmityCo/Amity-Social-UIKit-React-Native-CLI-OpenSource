import React from 'react';
import { UserInterface } from '../../../types/user.interface';
interface ICommunityMembersTab {
    activeTab: string;
    communityId: string;
    onThreeDotTap: (user: UserInterface) => void;
    setMember: (user: UserInterface[]) => void;
    shouldRefresh: boolean;
}
declare const _default: React.NamedExoticComponent<ICommunityMembersTab>;
export default _default;
//# sourceMappingURL=CommunityMembersTab.d.ts.map