import React from 'react';
import type { FeedRefType } from '../CommunityHome';
interface IFeed {
    targetId: string;
    targetType: string;
}
declare const _default: React.ForwardRefExoticComponent<IFeed & React.RefAttributes<FeedRefType>>;
export default _default;
//# sourceMappingURL=index.d.ts.map