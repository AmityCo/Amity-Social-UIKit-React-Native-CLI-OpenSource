import React from 'react';
declare const LiveStreamPlayer: ({ navigation, route }: {
    navigation: any;
    route: any;
}) => React.JSX.Element;
export default LiveStreamPlayer;
//# sourceMappingURL=index.d.ts.map