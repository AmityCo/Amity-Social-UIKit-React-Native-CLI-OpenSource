import React from 'react';
import { type CameraOptions, type ImageLibraryOptions } from 'react-native-image-picker';
interface EditProfileProps {
    navigation: any;
    route: any;
}
export interface Action {
    title: string;
    type: 'capture' | 'library';
    options: CameraOptions | ImageLibraryOptions;
}
export declare const EditProfile: React.FC<EditProfileProps>;
export {};
//# sourceMappingURL=EditProfile.d.ts.map