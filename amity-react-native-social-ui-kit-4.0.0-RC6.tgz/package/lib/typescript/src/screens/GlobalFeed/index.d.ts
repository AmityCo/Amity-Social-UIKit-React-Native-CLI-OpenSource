import React from 'react';
export default function GlobalFeed(): React.JSX.Element;
//# sourceMappingURL=index.d.ts.map