import React from 'react';
interface IHeader {
    targetName: string;
    goBack: () => void;
    isBtnDisable: boolean;
    handleCreatePost: () => void;
}
declare const _default: React.NamedExoticComponent<IHeader>;
export default _default;
//# sourceMappingURL=Header.d.ts.map