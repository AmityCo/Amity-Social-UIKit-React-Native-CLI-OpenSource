import React from 'react';
export type FeedRefType = {
    handleLoadMore: () => void;
};
export default function CommunityHome({ route }: any): React.JSX.Element;
//# sourceMappingURL=index.d.ts.map