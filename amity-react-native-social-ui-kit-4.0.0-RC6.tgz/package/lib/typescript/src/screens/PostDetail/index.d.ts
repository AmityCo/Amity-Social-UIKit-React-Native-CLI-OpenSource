import React from 'react';
declare const PostDetail: () => React.JSX.Element;
export default PostDetail;
//# sourceMappingURL=index.d.ts.map