import React from 'react';
declare const CreateLivestream: ({ navigation, route }: {
    navigation: any;
    route: any;
}) => React.JSX.Element;
export default CreateLivestream;
//# sourceMappingURL=CreateLivestream.d.ts.map