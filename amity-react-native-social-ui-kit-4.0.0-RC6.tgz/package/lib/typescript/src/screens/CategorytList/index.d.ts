import React from 'react';
export default function CategoryList({ navigation }: any): React.JSX.Element;
//# sourceMappingURL=index.d.ts.map