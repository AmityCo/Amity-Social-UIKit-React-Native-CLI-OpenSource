import { MyMD3Theme } from '../providers/amity-ui-kit-provider';
export declare const validateConfigColor: (color: string) => string;
export declare const hexToRgba: (hex: string, alpha: number) => string;
export declare const getSkeletonBackgrounColor: (themeColor: MyMD3Theme) => {
    backgroundColor: string;
    foregroundColor: string;
};
//# sourceMappingURL=colorUtil.d.ts.map