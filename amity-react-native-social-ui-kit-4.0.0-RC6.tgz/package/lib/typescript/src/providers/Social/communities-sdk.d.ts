export interface ICreateCommunity {
    description: string;
    displayName: string;
    isPublic: boolean;
    userIds?: string[];
    category: string;
    avatarFileId?: string;
}
export declare function getCommunityById(communityId: string): Promise<any>;
export declare function createCommunity(communityParam: ICreateCommunity): Promise<any>;
export declare const updateCommunity: (communityId: string, communityParam: ICreateCommunity) => Promise<Amity.Community | unknown>;
export declare function checkCommunityPermission(communityId: string, client: Amity.Client, apiRegion: string): Promise<any>;
export declare const updateCommunityMember: ({ operation, communityId, memberIds, }: {
    operation: "ADD" | "REMOVE";
    communityId: string;
    memberIds: string[];
}) => Promise<boolean>;
export declare const assignRolesToUsers: (communityId: string, roles: string[], userIds: string[]) => Promise<boolean>;
export declare const removeRolesFromUsers: (communityId: string, roles: string[], userIds: string[]) => Promise<boolean>;
//# sourceMappingURL=communities-sdk.d.ts.map