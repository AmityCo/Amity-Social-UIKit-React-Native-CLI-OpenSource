import { IMentionPosition } from '../../screens/CreatePost';
export interface IGlobalFeedRes {
    data: Amity.Post<any>[];
    nextPage?: string;
    prevPage?: string;
}
export declare function getGlobalFeed({ limit, callback, }: {
    limit?: number;
    callback: Amity.LiveCollectionCallback<Amity.Post>;
}): Amity.Unsubscriber;
export declare function addPostReaction(postId: string, reactionName: string): Promise<boolean>;
export declare function removePostReaction(postId: string, reactionName: string): Promise<boolean>;
export declare function getPostById(postId: string): Promise<any>;
export declare function createPostToFeed(targetType: string, targetId: string, content: {
    text: string;
    fileIds: string[];
}, postType: string, mentionees: string[], mentionPosition: IMentionPosition[]): Promise<Amity.Post<any>>;
export declare function editPost(postId: string, content: {
    text: string;
    fileIds: string[];
}, postType: string, mentionees: string[], mentionPosition: IMentionPosition[]): Promise<Amity.Post<any>>;
export declare function deletePostById(postId: string): Promise<boolean>;
export declare function reportTargetById(targetType: 'post' | 'comment', postId: string): Promise<boolean>;
export declare function isReportTarget(targetType: 'post' | 'comment' | 'user', targetId: string): Promise<boolean>;
export declare function unReportTargetById(targetType: 'post' | 'comment', targetId: string): Promise<boolean>;
//# sourceMappingURL=feed-sdk.d.ts.map