export {};
//# sourceMappingURL=AmityTopSearchBarComponent.d.ts.map