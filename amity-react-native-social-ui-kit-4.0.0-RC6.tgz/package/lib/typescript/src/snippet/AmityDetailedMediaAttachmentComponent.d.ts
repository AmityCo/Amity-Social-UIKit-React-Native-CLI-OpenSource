export {};
//# sourceMappingURL=AmityDetailedMediaAttachmentComponent.d.ts.map