export {};
//# sourceMappingURL=AmityNewsFeedComponent.d.ts.map