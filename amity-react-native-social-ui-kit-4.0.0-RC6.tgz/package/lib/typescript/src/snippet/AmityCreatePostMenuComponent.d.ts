export {};
//# sourceMappingURL=AmityCreatePostMenuComponent.d.ts.map