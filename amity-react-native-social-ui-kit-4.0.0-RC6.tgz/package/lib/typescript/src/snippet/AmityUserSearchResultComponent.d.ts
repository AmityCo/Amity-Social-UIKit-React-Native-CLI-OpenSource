export {};
//# sourceMappingURL=AmityUserSearchResultComponent.d.ts.map