export {};
//# sourceMappingURL=AmityReactionListComponent.d.ts.map