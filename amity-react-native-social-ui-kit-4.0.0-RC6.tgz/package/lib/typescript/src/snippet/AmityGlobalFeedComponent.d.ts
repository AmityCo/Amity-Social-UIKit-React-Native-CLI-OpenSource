export {};
//# sourceMappingURL=AmityGlobalFeedComponent.d.ts.map