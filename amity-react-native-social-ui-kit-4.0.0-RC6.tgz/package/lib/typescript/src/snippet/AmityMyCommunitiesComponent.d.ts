export {};
//# sourceMappingURL=AmityMyCommunitiesComponent.d.ts.map