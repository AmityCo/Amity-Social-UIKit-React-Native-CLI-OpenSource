export {};
//# sourceMappingURL=AmityMyCommunitiesSearchPage.d.ts.map