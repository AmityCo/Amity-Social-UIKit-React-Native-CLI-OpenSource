export {};
//# sourceMappingURL=AmityPostDetailPage.d.ts.map