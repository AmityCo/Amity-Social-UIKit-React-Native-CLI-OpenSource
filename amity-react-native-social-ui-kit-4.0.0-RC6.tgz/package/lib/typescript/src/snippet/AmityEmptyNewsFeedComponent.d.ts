export {};
//# sourceMappingURL=AmityEmptyNewsFeedComponent.d.ts.map