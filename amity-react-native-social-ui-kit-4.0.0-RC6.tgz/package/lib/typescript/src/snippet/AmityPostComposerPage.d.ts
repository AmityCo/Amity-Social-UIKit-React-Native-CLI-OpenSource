export {};
//# sourceMappingURL=AmityPostComposerPage.d.ts.map