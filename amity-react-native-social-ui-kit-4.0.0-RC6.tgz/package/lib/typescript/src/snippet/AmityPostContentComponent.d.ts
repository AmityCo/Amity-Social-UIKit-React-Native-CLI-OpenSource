export {};
//# sourceMappingURL=AmityPostContentComponent.d.ts.map