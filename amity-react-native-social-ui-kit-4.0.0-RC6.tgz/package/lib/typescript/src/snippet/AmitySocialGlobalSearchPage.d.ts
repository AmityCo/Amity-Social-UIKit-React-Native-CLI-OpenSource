export {};
//# sourceMappingURL=AmitySocialGlobalSearchPage.d.ts.map