export {};
//# sourceMappingURL=AmityCommunitySearchResultComponent.d.ts.map