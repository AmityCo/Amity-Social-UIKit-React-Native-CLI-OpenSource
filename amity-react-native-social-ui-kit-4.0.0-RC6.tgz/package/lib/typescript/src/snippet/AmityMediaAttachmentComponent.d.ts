export {};
//# sourceMappingURL=AmityMediaAttachmentComponent.d.ts.map