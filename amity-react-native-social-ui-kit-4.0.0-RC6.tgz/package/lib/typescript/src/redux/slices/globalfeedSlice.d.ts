import { PayloadAction } from '@reduxjs/toolkit';
interface GlobalFeedState {
    postList: (Amity.Post<any> | Amity.Ad)[];
    paginationData: {
        next: string | null;
        previous: string | null;
    };
}
declare const globalFeedSlice: import("@reduxjs/toolkit").Slice<GlobalFeedState, {
    setNewGlobalFeed: (state: import("immer/dist/internal").WritableDraft<GlobalFeedState>, action: PayloadAction<Amity.Post<any>[]>) => void;
    updateGlobalFeed: (state: import("immer/dist/internal").WritableDraft<GlobalFeedState>, action: PayloadAction<Amity.Post<any>[]>) => void;
    setPaginationData: (state: import("immer/dist/internal").WritableDraft<GlobalFeedState>, action: PayloadAction<{
        next: string | null;
        previous: string | null;
    }>) => void;
    addPostToGlobalFeed: (state: import("immer/dist/internal").WritableDraft<GlobalFeedState>, action: PayloadAction<Amity.Post<any>>) => void;
    updateByPostId: (state: import("immer/dist/internal").WritableDraft<GlobalFeedState>, action: PayloadAction<{
        postId: string;
        postDetail: Amity.Post<any>;
    }>) => void;
    deleteByPostId: (state: import("immer/dist/internal").WritableDraft<GlobalFeedState>, action: PayloadAction<{
        postId: string;
    }>) => void;
    clearFeed: (state: import("immer/dist/internal").WritableDraft<GlobalFeedState>) => void;
}, "globalFeed">;
export default globalFeedSlice;
//# sourceMappingURL=globalfeedSlice.d.ts.map