import { PayloadAction } from '@reduxjs/toolkit';
interface FeedState {
    postList: Amity.Post<any>[];
}
declare const feedSlice: import("@reduxjs/toolkit").Slice<FeedState, {
    updateFeed: (state: import("immer/dist/internal").WritableDraft<FeedState>, action: PayloadAction<Amity.Post<any>[]>) => void;
    addPostToFeed: (state: import("immer/dist/internal").WritableDraft<FeedState>, action: PayloadAction<Amity.Post<any>>) => void;
    updateByPostId: (state: import("immer/dist/internal").WritableDraft<FeedState>, action: PayloadAction<{
        postId: string;
        postDetail: Amity.Post<any>;
    }>) => void;
    deleteByPostId: (state: import("immer/dist/internal").WritableDraft<FeedState>, action: PayloadAction<{
        postId: string;
    }>) => void;
    clearFeed: (state: import("immer/dist/internal").WritableDraft<FeedState>) => void;
}, "feed">;
export default feedSlice;
//# sourceMappingURL=feedSlice.d.ts.map