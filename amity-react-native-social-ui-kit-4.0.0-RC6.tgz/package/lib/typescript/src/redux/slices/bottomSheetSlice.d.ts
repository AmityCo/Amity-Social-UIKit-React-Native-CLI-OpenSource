import { ComponentID, PageID } from '../../v4/enum';
import { PayloadAction } from '@reduxjs/toolkit';
export interface BottomSheetState {
    open: boolean;
    content: JSX.Element | null;
    height?: number;
    pageId?: PageID;
    componentId?: ComponentID;
}
type OpenBottomSheetPayload = {
    content: JSX.Element;
    height?: number;
};
declare const bottomSheetSlice: import("@reduxjs/toolkit").Slice<BottomSheetState, {
    openBottomSheet: (state: import("immer/dist/internal").WritableDraft<BottomSheetState>, action: PayloadAction<OpenBottomSheetPayload>) => void;
    closeBottomSheet: (state: import("immer/dist/internal").WritableDraft<BottomSheetState>) => void;
    clearContent: (state: import("immer/dist/internal").WritableDraft<BottomSheetState>) => void;
}, "bottomSheet">;
export default bottomSheetSlice;
export declare const useBottomSheet: () => {
    openBottomSheet: ({ content, height }: OpenBottomSheetPayload) => void;
    height: number;
    closeBottomSheet: () => void;
    content: JSX.Element;
    open: boolean;
};
//# sourceMappingURL=bottomSheetSlice.d.ts.map