import { Store } from '@reduxjs/toolkit';
export declare const AmityUIKitReduxContext: import("react").Context<any>;
export declare const useUIKitStore: <State = unknown, Action extends import("redux").Action<any> = import("redux").AnyAction>() => Store<State, Action>;
export declare const useUIKitDispatch: <AppDispatch extends import("redux").Dispatch<import("redux").AnyAction> = import("redux").Dispatch<import("redux").AnyAction>>() => AppDispatch;
export declare const useUIKitSelector: import("react-redux/es/hooks/useSelector").UseSelector;
export declare const store: Store;
export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;
//# sourceMappingURL=index.d.ts.map