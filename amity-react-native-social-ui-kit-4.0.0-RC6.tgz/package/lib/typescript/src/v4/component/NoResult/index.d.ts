export { default } from './NoResult';
//# sourceMappingURL=index.d.ts.map