import React from 'react';
import { PageID } from '../../enum';
type CommnetAdComponentType = {
    pageId?: PageID;
    ad?: Amity.Ad;
};
declare const _default: React.NamedExoticComponent<CommnetAdComponentType>;
export default _default;
//# sourceMappingURL=CommentAdComponent.d.ts.map