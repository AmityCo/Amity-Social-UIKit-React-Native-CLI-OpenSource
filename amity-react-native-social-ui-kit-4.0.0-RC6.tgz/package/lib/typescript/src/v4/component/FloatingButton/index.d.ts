import React from 'react';
interface IFloatingButton {
    onPress: () => any;
    isGlobalFeed?: boolean;
}
export default function FloatingButton({ onPress, isGlobalFeed, }: IFloatingButton): React.JSX.Element;
export {};
//# sourceMappingURL=index.d.ts.map