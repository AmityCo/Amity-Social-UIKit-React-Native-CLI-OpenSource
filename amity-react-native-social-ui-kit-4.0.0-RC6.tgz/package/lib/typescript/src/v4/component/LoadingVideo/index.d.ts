import React from 'react';
interface OverlayImageProps {
    source: string;
    onClose?: (originalPath: string, fileId?: string, postId?: string) => void;
    onLoadFinish?: (fileId: string, fileUrl: string, fileName: string, index: number, originalPath: string, thumbNail: string) => void;
    index?: number;
    isUploaded: boolean;
    fileId?: string;
    thumbNail: string;
    onPlay?: (fileUrl: string) => void;
    isEditMode?: boolean;
    fileCount?: number;
    postId?: string;
    setIsUploading?: (arg: boolean) => void;
}
declare const LoadingVideo: ({ source, onClose, index, onLoadFinish, isUploaded, thumbNail, onPlay, fileId, isEditMode, fileCount, postId, setIsUploading, }: OverlayImageProps) => React.JSX.Element;
export default LoadingVideo;
//# sourceMappingURL=index.d.ts.map