export { default } from './FormInput';
//# sourceMappingURL=index.d.ts.map