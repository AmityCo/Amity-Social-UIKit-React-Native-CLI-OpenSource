import React from 'react';
import { TextInputProps } from 'react-native';
import { ElementID, PageID, ComponentID } from '../../enum';
type FormInputProps = TextInputProps & {
    pageId?: PageID;
    maxLength?: number;
    elementId?: ElementID;
    componentId?: ComponentID;
    optional?: boolean;
};
declare function FormInput({ value, optional, maxLength, pageId, elementId, componentId, ...props }: FormInputProps): React.JSX.Element;
export default FormInput;
//# sourceMappingURL=FormInput.d.ts.map