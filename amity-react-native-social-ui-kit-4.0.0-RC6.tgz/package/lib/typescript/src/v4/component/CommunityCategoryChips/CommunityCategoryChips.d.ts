import React from 'react';
import { ViewProps } from 'react-native';
import type { MyMD3Theme } from 'src/providers/amity-ui-kit-provider';
type CommunityCategoryChipsProps = ViewProps & {
    themeStyles: MyMD3Theme;
    categoryIds: string[];
    allVisible?: boolean;
};
export declare const CommunityCategoryChips: React.FC<CommunityCategoryChipsProps>;
export {};
//# sourceMappingURL=CommunityCategoryChips.d.ts.map