import React from 'react';
import { MyMD3Theme } from 'src/providers/amity-ui-kit-provider';
type CommunityCategoryChipProps = {
    categoryId: string;
    style?: object;
    maxWidth?: number | string;
    themeStyles?: MyMD3Theme;
};
export declare const CommunityCategoryChip: React.FC<CommunityCategoryChipProps>;
export {};
//# sourceMappingURL=CommunityCategoryChip.d.ts.map