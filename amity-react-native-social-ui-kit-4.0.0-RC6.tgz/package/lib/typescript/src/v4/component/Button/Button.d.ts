import React from 'react';
import { StyleProp, ViewStyle, TextStyle, TouchableOpacityProps } from 'react-native';
import { MyMD3Theme } from 'src/providers/amity-ui-kit-provider';
import { XmlProps } from 'react-native-svg';
export declare const enum BUTTON_SIZE {
    SMALL = "small",
    LARGE = "large"
}
export type ButtonProps = TouchableOpacityProps & {
    iconProps?: XmlProps;
    size?: BUTTON_SIZE;
    type?: 'primary' | 'secondary' | 'inverse' | 'inline';
    icon?: string;
    children?: React.ReactNode;
    style?: StyleProp<ViewStyle>;
    textStyle?: StyleProp<TextStyle>;
    themeStyle?: MyMD3Theme;
};
export declare const Button: ({ icon, children, style, iconProps, size, type, textStyle, themeStyle, disabled, ...props }: ButtonProps) => React.JSX.Element;
export default Button;
//# sourceMappingURL=Button.d.ts.map