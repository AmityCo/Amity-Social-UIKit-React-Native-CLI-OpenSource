import React from 'react';
interface ICommunityStories {
    communityId: string;
    community: Amity.Community;
}
declare const _default: React.MemoExoticComponent<({ communityId, community }: ICommunityStories) => React.JSX.Element>;
export default _default;
//# sourceMappingURL=index.d.ts.map