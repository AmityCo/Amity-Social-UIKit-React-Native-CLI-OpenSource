import React from 'react';
import { MyMD3Theme } from '../../../providers/amity-ui-kit-provider';
type ErrorComponentProps = {
    title: string;
    description?: string;
    themeStyle?: MyMD3Theme;
    icon?: () => string;
    onPress?: () => void;
};
declare const _default: React.NamedExoticComponent<ErrorComponentProps>;
export default _default;
//# sourceMappingURL=ErrorComponent.d.ts.map