import React from 'react';
import { IMentionPosition } from '../../../types';
interface IPostContent {
    post: Amity.Post;
    textPost?: string;
    disabledPoll?: boolean;
    childrenPosts: string[];
    onPressPost?: () => void;
    showedAllOptions?: boolean;
    mentionPositionArr?: IMentionPosition[];
}
declare const _default: React.NamedExoticComponent<IPostContent>;
export default _default;
//# sourceMappingURL=index.d.ts.map