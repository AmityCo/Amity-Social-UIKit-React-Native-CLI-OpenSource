export * from './src/interfaces';
export declare const AmityStory: {
    ({ data, onClose, duration, onStorySeen, isCommunityStory, }: import("./src/interfaces").StoryProps): import("react").JSX.Element;
    defaultProps: {
        showAvatarText: boolean;
    };
};
export default AmityStory;
//# sourceMappingURL=index.d.ts.map