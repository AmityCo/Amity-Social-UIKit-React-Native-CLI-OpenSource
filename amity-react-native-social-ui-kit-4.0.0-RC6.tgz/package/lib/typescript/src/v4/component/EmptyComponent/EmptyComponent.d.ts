import React from 'react';
import { MyMD3Theme } from '../../../providers/amity-ui-kit-provider';
type EmptyComponentProps = {
    title: string;
    description?: string;
    themeStyle?: MyMD3Theme;
    icon?: () => string;
};
declare const _default: React.NamedExoticComponent<EmptyComponentProps>;
export default _default;
//# sourceMappingURL=EmptyComponent.d.ts.map