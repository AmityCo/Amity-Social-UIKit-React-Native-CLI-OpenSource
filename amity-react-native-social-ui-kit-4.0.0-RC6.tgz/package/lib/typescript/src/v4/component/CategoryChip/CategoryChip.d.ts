import React from 'react';
type CategoryChipProps = {
    category: Amity.Category;
    onPress?: (category: Amity.Category) => void;
};
declare function CategoryChip({ category, onPress }: CategoryChipProps): React.JSX.Element;
export default CategoryChip;
//# sourceMappingURL=CategoryChip.d.ts.map