export { default } from './CategoryChip';
//# sourceMappingURL=index.d.ts.map