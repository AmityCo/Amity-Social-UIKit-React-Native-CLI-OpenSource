import React from 'react';
import { MyMD3Theme } from '../../../providers/amity-ui-kit-provider';
type IconTabProps = {
    isActive: boolean;
    icon: React.ReactNode;
    themeStyles: MyMD3Theme;
};
declare const _default: React.NamedExoticComponent<IconTabProps>;
export default _default;
//# sourceMappingURL=IconTab.d.ts.map