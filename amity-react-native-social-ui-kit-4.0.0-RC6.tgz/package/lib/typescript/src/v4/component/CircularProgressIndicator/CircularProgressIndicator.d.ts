import React from 'react';
type CircularProgressIndicatorProps = {
    progress?: number;
    size?: number;
    strokeWidth?: number;
    backgroundColor?: string;
    progressColor?: string;
    backgroundOpacity?: number;
    duration?: number;
};
export declare const CircularProgressIndicator: React.FC<CircularProgressIndicatorProps>;
export {};
//# sourceMappingURL=CircularProgressIndicator.d.ts.map