import React from 'react';
import { MyMD3Theme } from '../../../providers/amity-ui-kit-provider';
type CommunityListSkeletonProps = {
    hasTitle?: boolean;
    themeStyle?: MyMD3Theme;
    amount?: number;
};
declare const _default: React.NamedExoticComponent<CommunityListSkeletonProps>;
export default _default;
//# sourceMappingURL=CommunityListSkeleton.d.ts.map