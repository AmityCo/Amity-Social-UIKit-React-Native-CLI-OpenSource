import React from 'react';
import { ComponentID, PageID } from '../../enum';
type PostMenuProps = {
    pageId?: PageID;
    componentId?: ComponentID;
    post: Amity.Post<any>;
};
export declare function PostMenu({ pageId, componentId, post }: PostMenuProps): React.JSX.Element;
export {};
//# sourceMappingURL=index.d.ts.map