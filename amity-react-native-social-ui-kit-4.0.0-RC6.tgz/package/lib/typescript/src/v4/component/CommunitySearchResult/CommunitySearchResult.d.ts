import { FC } from 'react';
import { MyMD3Theme } from '../../../providers/amity-ui-kit-provider';
import { ComponentID, PageID } from '../../enum';
type CommunitySearchResultProps = {
    pageId?: PageID;
    componentId?: ComponentID;
    communities?: Amity.Community[];
    isLoading?: boolean;
    isFirstTimeLoading?: boolean;
    themeStyles?: MyMD3Theme;
    onNextPage?: () => void;
    onPressCommunity?: ({ communityId, communityName, }: {
        communityId: string;
        communityName: string;
    }) => void;
};
declare const CommunitySearchResult: FC<CommunitySearchResultProps>;
export default CommunitySearchResult;
//# sourceMappingURL=CommunitySearchResult.d.ts.map