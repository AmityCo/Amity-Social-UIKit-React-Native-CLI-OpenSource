export { default } from './LimitCharacterSearch';
//# sourceMappingURL=index.d.ts.map