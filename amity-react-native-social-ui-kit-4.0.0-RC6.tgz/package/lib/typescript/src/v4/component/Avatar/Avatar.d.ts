import React from 'react';
import { ImageProps, ImageStyle, StyleProp } from 'react-native';
import { XmlProps } from 'react-native-svg';
type AvatarProps = {
    uri?: string;
    imageProps: Omit<ImageProps, 'source'>;
    iconProps?: XmlProps;
    userAvatarProps?: {
        userName?: string;
        userId?: string;
        style?: StyleProp<ImageStyle>;
        roles?: string[];
        shouldRedirectToUserProfile?: boolean;
    };
};
declare function Avatar({ uri, imageProps, iconProps, userAvatarProps }: AvatarProps): React.JSX.Element;
declare namespace Avatar {
    var Category: typeof CategoryAvatar;
    var User: typeof UserAvatar;
}
type CategoryAvatarProps = {
    uri?: string;
    imageStyle?: StyleProp<ImageStyle>;
    iconProps?: Pick<XmlProps, 'width' | 'height'>;
};
declare function CategoryAvatar({ uri, imageStyle, iconProps: $iconProps, }: CategoryAvatarProps): React.JSX.Element;
type UserAvatarProps = {
    uri?: string;
    userId?: string;
    roles?: string[];
    userName?: string;
    imageStyle?: StyleProp<ImageStyle>;
    shouldRedirectToUserProfile?: boolean;
};
declare function UserAvatar({ uri, roles, userId, userName, imageStyle, shouldRedirectToUserProfile, }: UserAvatarProps): React.JSX.Element;
export default Avatar;
//# sourceMappingURL=Avatar.d.ts.map