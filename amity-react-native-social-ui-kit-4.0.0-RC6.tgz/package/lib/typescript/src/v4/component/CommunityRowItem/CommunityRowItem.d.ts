import React from 'react';
import { MyMD3Theme } from 'src/providers/amity-ui-kit-provider';
import { ComponentID, PageID } from '../../enum';
type CommunityRowItemProps = {
    pageId?: PageID;
    componentId?: ComponentID;
    themeStyles?: MyMD3Theme;
    community: Amity.Community;
    showJoinButton?: boolean;
    label?: string;
};
declare const _default: React.NamedExoticComponent<CommunityRowItemProps>;
export default _default;
//# sourceMappingURL=CommunityRowItem.d.ts.map