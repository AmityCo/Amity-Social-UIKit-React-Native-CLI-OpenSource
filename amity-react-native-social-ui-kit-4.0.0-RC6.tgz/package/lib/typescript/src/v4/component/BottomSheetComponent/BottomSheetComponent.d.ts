import React from 'react';
declare const _default: React.MemoExoticComponent<() => React.JSX.Element>;
export default _default;
//# sourceMappingURL=BottomSheetComponent.d.ts.map