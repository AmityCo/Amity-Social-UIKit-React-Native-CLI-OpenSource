import React, { PropsWithChildren } from 'react';
import { ViewStyle, ViewProps, PressableProps, StyleProp } from 'react-native';
import { XmlProps } from 'react-native-svg';
type CheckBoxContextType<T extends any = string> = {
    value: T[];
    disabled?: boolean;
    onChange: (value: T[]) => void;
    select?: (value: T[], option: T) => boolean;
    extractKey?: (value: T) => string;
};
type GroupProps<T> = CheckBoxContextType<T> & PropsWithChildren<ViewProps>;
declare function Group<T>({ value, select, onChange, children, disabled, extractKey, ...props }: GroupProps<T>): React.JSX.Element;
type OptionProps<T extends any = string> = PropsWithChildren<Omit<PressableProps, 'style'>> & {
    style?: (state: {
        pressed: boolean;
        selected: boolean;
        disabled: boolean;
    }) => StyleProp<ViewStyle>;
    disabled?: boolean;
    value: T;
};
declare function Option<T extends any = string>({ style, value, children, disabled, accessibilityHint, accessibilityLabel, ...props }: OptionProps<T>): React.JSX.Element;
type IconProps = Omit<XmlProps, 'xml'> & {
    style?: ViewStyle;
};
type LabelProps = ViewProps;
export declare const CheckBox: {
    Group: typeof Group;
    Option: typeof Option;
    Icon: ({ width, height, style, ...props }: IconProps) => React.JSX.Element;
    Label: ({ children, ...props }: LabelProps) => React.JSX.Element;
};
export {};
//# sourceMappingURL=index.d.ts.map