import React from 'react';
type PollContentProps = {
    pollId: string;
    post: Amity.Post<any>;
    disabledPoll?: boolean;
    showedAllOptions?: boolean;
};
declare const PollContent: ({ post, pollId, disabledPoll, showedAllOptions, }: PollContentProps) => React.JSX.Element;
export default PollContent;
//# sourceMappingURL=index.d.ts.map