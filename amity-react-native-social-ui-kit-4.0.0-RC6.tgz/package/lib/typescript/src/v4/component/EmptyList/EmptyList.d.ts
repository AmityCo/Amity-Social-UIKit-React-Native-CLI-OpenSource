import React from 'react';
import { ViewProps } from 'react-native';
type EmptyListProps = ViewProps;
declare function EmptyList(props: EmptyListProps): React.JSX.Element;
export default EmptyList;
//# sourceMappingURL=EmptyList.d.ts.map