export { default } from './EmptyList';
//# sourceMappingURL=index.d.ts.map