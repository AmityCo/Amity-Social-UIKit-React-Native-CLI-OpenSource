import React from 'react';
interface ILivestreamContent {
    streamId: Amity.Stream['streamId'];
    onPressPost: () => void;
    post: Amity.Post;
}
declare const _default: React.NamedExoticComponent<ILivestreamContent>;
export default _default;
//# sourceMappingURL=index.d.ts.map