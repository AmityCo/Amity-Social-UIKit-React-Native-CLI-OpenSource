import React from 'react';
declare const LiveStreamIdleThumbnail: () => React.JSX.Element;
export default LiveStreamIdleThumbnail;
//# sourceMappingURL=index.d.ts.map