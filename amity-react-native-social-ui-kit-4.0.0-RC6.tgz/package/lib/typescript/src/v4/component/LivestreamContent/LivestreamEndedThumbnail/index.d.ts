import React from 'react';
declare const LiveStreamEndThumbnail: () => React.JSX.Element;
export default LiveStreamEndThumbnail;
//# sourceMappingURL=index.d.ts.map