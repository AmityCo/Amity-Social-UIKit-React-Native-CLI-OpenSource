import React from 'react';
declare const LiveStreamTerminatedThumbnail: () => React.JSX.Element;
export default LiveStreamTerminatedThumbnail;
//# sourceMappingURL=index.d.ts.map