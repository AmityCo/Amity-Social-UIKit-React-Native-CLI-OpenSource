import { FC } from 'react';
import type { MyMD3Theme } from 'src/providers/amity-ui-kit-provider';
export type DividerProps = {
    themeStyles?: MyMD3Theme;
};
declare const Divider: FC<DividerProps>;
export default Divider;
//# sourceMappingURL=index.d.ts.map