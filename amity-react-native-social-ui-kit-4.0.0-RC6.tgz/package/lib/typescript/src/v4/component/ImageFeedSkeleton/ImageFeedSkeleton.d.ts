import React from 'react';
import { MyMD3Theme } from '../../../providers/amity-ui-kit-provider';
type ImageFeedSkeletonProps = {
    themeStyles: MyMD3Theme;
};
declare function ImageFeedSkeleton({ themeStyles }: ImageFeedSkeletonProps): React.JSX.Element;
export default ImageFeedSkeleton;
//# sourceMappingURL=ImageFeedSkeleton.d.ts.map