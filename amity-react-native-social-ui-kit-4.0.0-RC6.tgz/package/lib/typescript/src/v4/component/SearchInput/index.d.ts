export { default } from './SearchInput';
//# sourceMappingURL=index.d.ts.map