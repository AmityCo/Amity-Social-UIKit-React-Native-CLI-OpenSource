import React from 'react';
import { PageID } from '../../enum';
type AdInformationType = {
    pageId?: PageID;
    companyName: string;
};
declare const _default: React.NamedExoticComponent<AdInformationType>;
export default _default;
//# sourceMappingURL=AdInformation.d.ts.map