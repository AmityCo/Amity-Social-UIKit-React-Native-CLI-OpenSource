import React from 'react';
import { TabName } from '../../enum/enumTabName';
type TCustomTab = {
    onTabChange: (tabName: TabName) => void;
    tabNames: TabName[] | string[];
    activeTab: TabName | string;
};
declare const _default: React.NamedExoticComponent<TCustomTab>;
export default _default;
//# sourceMappingURL=CustomSocialTab.d.ts.map