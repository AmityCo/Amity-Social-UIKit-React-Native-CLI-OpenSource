import React from 'react';
interface ICommentListProp {
    postId: string;
    postType: Amity.CommentReferenceType;
    disabledInteraction?: boolean;
    onNavigate?: () => void;
    withAvatar?: boolean;
}
declare const _default: React.NamedExoticComponent<ICommentListProp>;
export default _default;
//# sourceMappingURL=CommentList.d.ts.map