import React from 'react';
import type { UserInterface, IMentionPosition } from '../../../../types';
export interface IComment {
    commentId: string;
    data: Record<string, any>;
    dataType: string | undefined;
    myReactions: string[];
    reactions: Record<string, number>;
    user: UserInterface | undefined;
    updatedAt: string | undefined;
    editedAt: string | undefined;
    createdAt: string;
    childrenComment: string[];
    referenceId: string;
    mentionees?: string[];
    mentionPosition?: IMentionPosition[];
    childrenNumber: number;
}
export interface ICommentList {
    commentDetail: IComment;
    isReplyComment?: boolean;
    onDelete: (commentId: string) => void;
    onClickReply: (user: UserInterface, commentId: string) => void;
    postType: Amity.CommentReferenceType;
    disabledInteraction?: boolean;
    onNavigate?: () => void;
}
declare const CommentListItem: ({ commentDetail, onDelete, onClickReply, postType, disabledInteraction, onNavigate, }: ICommentList) => React.JSX.Element;
export default CommentListItem;
//# sourceMappingURL=CommentListItem.d.ts.map