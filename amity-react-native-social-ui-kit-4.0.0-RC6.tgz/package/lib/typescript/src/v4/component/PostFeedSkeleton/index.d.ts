export { default } from './PostFeedSkeleton';
//# sourceMappingURL=index.d.ts.map