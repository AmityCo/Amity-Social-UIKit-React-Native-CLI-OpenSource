export declare const getCommentErrorMessage: (error: Error) => string;
export declare const getPostErrorMessage: (error: Error, isEditMode?: boolean) => string;
//# sourceMappingURL=errors.d.ts.map