import * as React from 'react';
export default function AmitySocialUIKitV4Navigator(): React.JSX.Element;
//# sourceMappingURL=AmitySocialUIKitV4Navigator.d.ts.map