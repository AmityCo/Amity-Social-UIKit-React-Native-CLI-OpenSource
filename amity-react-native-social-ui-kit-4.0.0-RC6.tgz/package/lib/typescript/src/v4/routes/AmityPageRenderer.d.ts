import * as React from 'react';
interface PageRendererProps {
    children: React.JSX.Element;
}
export default function PageRenderer({ children }: PageRendererProps): React.JSX.Element;
export {};
//# sourceMappingURL=AmityPageRenderer.d.ts.map