export declare enum AmityPostContentComponentStyleEnum {
    feed = "feed",
    detail = "detail"
}
export declare enum AmityPostCategory {
    GENERAL = "general",
    ANNOUNCEMENT = "announcement",
    PIN = "pin",
    PIN_AND_ANNOUNCEMENT = "pin_and_announcement"
}
//# sourceMappingURL=AmityPostContentComponentStyle.d.ts.map