import React from 'react';
import { TouchableOpacityProps } from 'react-native';
import { ComponentID, PageID } from '../../enum/enumUIKitID';
type ExploreCreateCommunityType = {
    pageId?: PageID;
    componentId?: ComponentID;
} & TouchableOpacityProps;
declare const _default: React.NamedExoticComponent<ExploreCreateCommunityType>;
export default _default;
//# sourceMappingURL=ExploreCreateCommunity.d.ts.map