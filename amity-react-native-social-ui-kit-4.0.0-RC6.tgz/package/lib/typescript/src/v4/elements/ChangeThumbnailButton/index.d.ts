export { default as ChangeThumbnailButton } from './ChangeThumbnailButton';
//# sourceMappingURL=index.d.ts.map