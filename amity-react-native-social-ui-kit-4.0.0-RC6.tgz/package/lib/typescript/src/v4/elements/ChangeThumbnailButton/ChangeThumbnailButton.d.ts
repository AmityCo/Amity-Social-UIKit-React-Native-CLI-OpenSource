import { TouchableOpacityProps } from 'react-native';
import { ComponentID, PageID } from '../../enum/enumUIKitID';
type ChangeThumbnailButtonProps = TouchableOpacityProps & {
    pageId?: PageID;
    componentId?: ComponentID;
};
declare const ChangeThumbnailButton: ({ pageId, componentId, ...props }: ChangeThumbnailButtonProps) => JSX.Element;
export default ChangeThumbnailButton;
//# sourceMappingURL=ChangeThumbnailButton.d.ts.map