import { FC } from 'react';
import { ComponentID, PageID } from '../../enum';
type CommunityOfficialBadgeProps = {
    pageId?: PageID;
    componentId?: ComponentID;
};
declare const CommunityOfficialBadge: FC<CommunityOfficialBadgeProps>;
export default CommunityOfficialBadge;
//# sourceMappingURL=CommunityOfficialBadge.d.ts.map