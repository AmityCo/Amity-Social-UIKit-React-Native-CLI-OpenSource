export { default } from './AnnouncementBadge';
//# sourceMappingURL=index.d.ts.map