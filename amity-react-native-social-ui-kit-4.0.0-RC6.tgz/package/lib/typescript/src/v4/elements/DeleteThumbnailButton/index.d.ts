export { default as DeleteThumbnailButton } from './DeleteThumbnailButton';
//# sourceMappingURL=index.d.ts.map