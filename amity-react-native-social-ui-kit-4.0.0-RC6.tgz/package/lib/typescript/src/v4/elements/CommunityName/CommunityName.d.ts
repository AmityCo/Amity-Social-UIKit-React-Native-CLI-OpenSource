import { FC } from 'react';
import { ComponentID, PageID } from '../../enum';
import { ViewProps } from 'react-native';
type CommunityNameProps = {
    communityName: string;
    pageId?: PageID;
    componentId?: ComponentID;
} & ViewProps;
declare const CommunityName: FC<CommunityNameProps>;
export default CommunityName;
//# sourceMappingURL=CommunityName.d.ts.map