import React from 'react';
import { ComponentID, PageID } from '../../enum';
type CommunityRowImageyProps = {
    fileId?: string;
    pageId?: PageID;
    componentId?: ComponentID;
    label?: string;
};
declare const _default: React.NamedExoticComponent<CommunityRowImageyProps>;
export default _default;
//# sourceMappingURL=CommunityRowImage.d.ts.map