export { default } from './BackButton';
//# sourceMappingURL=index.d.ts.map