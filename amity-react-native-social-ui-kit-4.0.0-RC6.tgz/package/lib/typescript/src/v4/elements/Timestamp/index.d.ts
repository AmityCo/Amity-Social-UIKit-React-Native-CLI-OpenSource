export { default } from './Timestamp';
//# sourceMappingURL=index.d.ts.map