import React from 'react';
import { TouchableOpacityProps } from 'react-native';
import { ComponentID, ElementID, PageID } from '../../../v4/enum';
type CameraButtonProps = TouchableOpacityProps & {
    pageId?: PageID;
    componentId?: ComponentID;
    elementId?: ElementID;
};
declare function CameraButton({ pageId, componentId, elementId, ...props }: CameraButtonProps): React.JSX.Element;
export default CameraButton;
//# sourceMappingURL=index.d.ts.map