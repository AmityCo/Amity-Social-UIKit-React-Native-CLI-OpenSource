import { FC } from 'react';
import { MyMD3Theme } from '../../../providers/amity-ui-kit-provider';
type ImageViewerProps = {
    currentImageIndex: number;
    images: string[];
    themeStyles?: MyMD3Theme;
    onNextImage: () => void;
    onPreviousImage: () => void;
    onClose?: () => void;
};
declare const ImageViewer: FC<ImageViewerProps>;
export default ImageViewer;
//# sourceMappingURL=ImageViewer.d.ts.map