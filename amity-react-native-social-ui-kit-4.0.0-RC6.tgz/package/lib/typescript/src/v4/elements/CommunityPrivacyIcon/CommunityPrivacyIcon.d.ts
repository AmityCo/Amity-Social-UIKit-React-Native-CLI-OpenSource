import React from 'react';
import { ViewProps } from 'react-native';
import { XmlProps } from 'react-native-svg';
import { ComponentID, ElementID, PageID } from '../../enum';
type CommunityPrivacyIconProps = ViewProps & {
    pageId?: PageID;
    componentId?: ComponentID;
    elementId?: ElementID;
    iconProps?: XmlProps;
};
declare function CommunityPrivacyIcon({ iconProps, pageId, elementId, componentId, ...props }: CommunityPrivacyIconProps): React.JSX.Element;
export default CommunityPrivacyIcon;
//# sourceMappingURL=CommunityPrivacyIcon.d.ts.map