export { default } from './CommunityPrivacyIcon';
//# sourceMappingURL=index.d.ts.map