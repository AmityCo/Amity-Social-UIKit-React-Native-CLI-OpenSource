import React from 'react';
import { PageID, ComponentID } from '../../enum';
type AllCategoriesTitleProps = {
    title: string;
    pageId?: PageID;
    componentId?: ComponentID;
};
declare const _default: React.NamedExoticComponent<AllCategoriesTitleProps>;
export default _default;
//# sourceMappingURL=AllCategoriesTitle.d.ts.map