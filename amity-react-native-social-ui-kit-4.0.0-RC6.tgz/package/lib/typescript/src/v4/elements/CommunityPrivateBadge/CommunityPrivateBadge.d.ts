import { FC } from 'react';
import { ComponentID, PageID } from '../../enum';
type CommunityPrivateBadgeProps = {
    pageId?: PageID;
    componentId?: ComponentID;
};
declare const CommunityPrivateBadge: FC<CommunityPrivateBadgeProps>;
export default CommunityPrivateBadge;
//# sourceMappingURL=CommunityPrivateBadge.d.ts.map