export { default } from './MenuButton';
//# sourceMappingURL=index.d.ts.map