import { FC } from 'react';
import { ComponentID, PageID } from '../../enum';
type CommunityVerifyBadgeProps = {
    pageId?: PageID;
    componentId?: ComponentID;
};
declare const CommunityVerifyBadge: FC<CommunityVerifyBadgeProps>;
export default CommunityVerifyBadge;
//# sourceMappingURL=CommunityVerifyBadge.d.ts.map