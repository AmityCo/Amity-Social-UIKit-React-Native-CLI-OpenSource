import React from 'react';
import { ComponentID, PageID } from '../../enum/enumUIKitID';
type CommunityJoinedButtonType = {
    pageId?: PageID;
    componentId?: ComponentID;
    communityId?: string;
};
declare const _default: React.NamedExoticComponent<CommunityJoinedButtonType>;
export default _default;
//# sourceMappingURL=CommunityJoinedButtonElement.d.ts.map