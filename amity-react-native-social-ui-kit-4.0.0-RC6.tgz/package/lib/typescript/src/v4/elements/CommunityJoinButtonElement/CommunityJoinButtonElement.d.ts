import React from 'react';
import { TouchableOpacityProps } from 'react-native';
import { ComponentID, PageID } from '../../enum/enumUIKitID';
import { BUTTON_SIZE } from '../../component/Button/Button';
type CommunityJoinButtonType = {
    pageId?: PageID;
    componentId?: ComponentID;
    communityId?: string;
    size?: BUTTON_SIZE;
    onJoinSuccess?: () => void;
} & TouchableOpacityProps;
declare const _default: React.NamedExoticComponent<CommunityJoinButtonType>;
export default _default;
//# sourceMappingURL=CommunityJoinButtonElement.d.ts.map