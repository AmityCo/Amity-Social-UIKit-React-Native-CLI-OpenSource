import React from 'react';
import { TouchableOpacityProps } from 'react-native';
import { ComponentID, PageID } from '../../enum';
type AddThumbnailButtonProps = TouchableOpacityProps & {
    pageId?: PageID;
    componentId?: ComponentID;
};
declare function AddThumbnailButton({ pageId, componentId, ...props }: AddThumbnailButtonProps): React.JSX.Element;
export default AddThumbnailButton;
//# sourceMappingURL=AddThumbnailButton.d.ts.map