export { default as AddThumbnailButton } from './AddThumbnailButton';
//# sourceMappingURL=index.d.ts.map