export { default as SwitchCameraButton } from './SwitchCameraButton';
//# sourceMappingURL=index.d.ts.map