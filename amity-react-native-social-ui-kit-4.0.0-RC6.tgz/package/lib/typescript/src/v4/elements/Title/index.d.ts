import React from 'react';
import { TextProps } from 'react-native';
import { ComponentID, ElementID, PageID } from '../../enum/enumUIKitID';
type TitleProps = Partial<TextProps> & {
    pageId?: PageID;
    componentId?: ComponentID;
    elementId?: ElementID;
    variant?: 'title' | 'body';
};
declare function Title({ children, variant, pageId, componentId, elementId, ...props }: TitleProps): React.JSX.Element;
export default Title;
//# sourceMappingURL=index.d.ts.map