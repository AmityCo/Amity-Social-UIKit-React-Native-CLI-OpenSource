import React from 'react';
import { PageID, ComponentID } from '../../enum';
type CommunityEmptyImageProps = {
    pageId?: PageID;
    componentId?: ComponentID;
};
declare const _default: React.NamedExoticComponent<CommunityEmptyImageProps>;
export default _default;
//# sourceMappingURL=CommunityEmptyImage.d.ts.map