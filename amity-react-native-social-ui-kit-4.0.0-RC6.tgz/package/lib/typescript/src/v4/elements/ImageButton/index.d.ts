import React from 'react';
import { TouchableOpacityProps } from 'react-native';
import { ComponentID, ElementID, PageID } from '../../../v4/enum';
type ImageButtonProps = TouchableOpacityProps & {
    pageId?: PageID;
    componentId?: ComponentID;
    elementId?: ElementID;
};
declare function ImageButton({ pageId, componentId, elementId, ...props }: ImageButtonProps): React.JSX.Element;
export default ImageButton;
//# sourceMappingURL=index.d.ts.map