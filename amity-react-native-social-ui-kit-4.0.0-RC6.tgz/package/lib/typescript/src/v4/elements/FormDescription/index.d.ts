import React from 'react';
import { TextProps } from 'react-native';
import { ComponentID, ElementID, PageID } from '../../enum/enumUIKitID';
type FormDescriptionProps = Partial<TextProps> & {
    pageId?: PageID;
    componentId?: ComponentID;
    elementId?: ElementID;
};
declare function FormDescription({ pageId, componentId, elementId, ...props }: FormDescriptionProps): React.JSX.Element;
export default FormDescription;
//# sourceMappingURL=index.d.ts.map