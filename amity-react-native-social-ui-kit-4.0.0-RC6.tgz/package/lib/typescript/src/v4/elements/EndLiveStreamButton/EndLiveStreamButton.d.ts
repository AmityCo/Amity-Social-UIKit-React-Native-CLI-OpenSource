import React from 'react';
import { ComponentID, PageID } from '../../enum';
import { TouchableOpacityProps } from 'react-native';
type EndLiveStreamButtonProps = TouchableOpacityProps & {
    pageId?: PageID;
    componentId?: ComponentID;
};
declare function EndLiveStreamButton({ pageId, componentId, ...props }: EndLiveStreamButtonProps): React.JSX.Element;
export default EndLiveStreamButton;
//# sourceMappingURL=EndLiveStreamButton.d.ts.map