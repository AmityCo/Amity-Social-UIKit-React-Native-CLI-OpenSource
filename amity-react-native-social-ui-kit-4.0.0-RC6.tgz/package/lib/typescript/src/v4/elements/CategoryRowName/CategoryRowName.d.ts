import React from 'react';
import { PageID, ComponentID } from '../../enum';
type CategoryRowNameProps = {
    name: string;
    pageId?: PageID;
    componentId?: ComponentID;
};
declare const _default: React.NamedExoticComponent<CategoryRowNameProps>;
export default _default;
//# sourceMappingURL=CategoryRowName.d.ts.map