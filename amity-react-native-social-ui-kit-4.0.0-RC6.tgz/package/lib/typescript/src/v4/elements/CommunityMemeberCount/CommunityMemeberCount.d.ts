import React from 'react';
import { ComponentID, PageID } from '../../enum';
type CommunityMemeberCountProps = {
    counts?: number;
    pageId?: PageID;
    componentId?: ComponentID;
};
declare const _default: React.NamedExoticComponent<CommunityMemeberCountProps>;
export default _default;
//# sourceMappingURL=CommunityMemeberCount.d.ts.map