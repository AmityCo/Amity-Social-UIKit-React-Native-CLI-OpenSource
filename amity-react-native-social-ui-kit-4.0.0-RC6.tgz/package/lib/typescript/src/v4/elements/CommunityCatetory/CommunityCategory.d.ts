import React from 'react';
import { ComponentID, PageID } from '../../enum';
import { ViewProps } from 'react-native';
type CommunityCategoryProps = ViewProps & {
    categoryIds?: Amity.Category['categoryId'][];
    pageId?: PageID;
    componentId?: ComponentID;
    allVisible?: boolean;
};
declare const _default: React.NamedExoticComponent<CommunityCategoryProps>;
export default _default;
//# sourceMappingURL=CommunityCategory.d.ts.map