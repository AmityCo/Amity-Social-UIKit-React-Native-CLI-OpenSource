import { FC } from 'react';
import { PageID, ComponentID } from '../../enum';
type CommunityCoverProps = {
    pageId?: PageID;
    componentId?: ComponentID;
    community: Amity.Community;
    smallHeader?: boolean;
    hideButtons?: boolean;
    isFromComponent?: boolean;
};
declare const CommunityCover: FC<CommunityCoverProps>;
export default CommunityCover;
//# sourceMappingURL=CommunityCover.d.ts.map