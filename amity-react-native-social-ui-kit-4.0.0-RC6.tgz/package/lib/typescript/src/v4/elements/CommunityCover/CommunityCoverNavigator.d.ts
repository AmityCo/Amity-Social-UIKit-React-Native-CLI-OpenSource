import { FC } from 'react';
import { PageID, ComponentID } from '../../enum';
type CommunityCoverNavigatorProps = {
    pageId?: PageID;
    componentId?: ComponentID;
    communityId: Amity.Community['communityId'];
    isFromComponent?: boolean;
};
declare const CommunityCoverNavigator: FC<CommunityCoverNavigatorProps>;
export default CommunityCoverNavigator;
//# sourceMappingURL=CommunityCoverNavigator.d.ts.map