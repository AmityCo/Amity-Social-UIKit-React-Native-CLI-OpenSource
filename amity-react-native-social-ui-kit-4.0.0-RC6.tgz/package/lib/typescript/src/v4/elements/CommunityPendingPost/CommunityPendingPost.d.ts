import { FC } from 'react';
import { ComponentID, PageID } from '../../enum';
import { ViewProps } from 'react-native';
type CommunityPendingPostProps = ViewProps & {
    number: number;
    pageId?: PageID;
    componentId?: ComponentID;
    onPress: () => void;
    isModerator?: boolean;
};
declare const CommunityPendingPost: FC<CommunityPendingPostProps>;
export default CommunityPendingPost;
//# sourceMappingURL=CommunityPendingPost.d.ts.map