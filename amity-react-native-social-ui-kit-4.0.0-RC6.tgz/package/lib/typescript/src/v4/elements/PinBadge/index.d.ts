export { default } from './PinBadge';
//# sourceMappingURL=index.d.ts.map