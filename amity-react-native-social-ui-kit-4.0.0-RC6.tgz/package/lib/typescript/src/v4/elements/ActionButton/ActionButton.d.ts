import React from 'react';
import { ComponentID, ElementID, PageID } from '../../../v4/enum';
import { ButtonProps } from '../../../v4/component/Button/Button';
type ActionButtonProps = ButtonProps & {
    pageId?: PageID;
    componentId?: ComponentID;
    elementId?: ElementID;
    fullWidth?: boolean;
    label?: string;
};
declare function ActionButton({ fullWidth, pageId, componentId, elementId, label, ...props }: ActionButtonProps): React.JSX.Element;
export default ActionButton;
//# sourceMappingURL=ActionButton.d.ts.map