import React from 'react';
import { PageID, ComponentID } from '../../enum';
type CommunityEmptyTitleProps = {
    pageId?: PageID;
    componentId?: ComponentID;
};
declare const _default: React.NamedExoticComponent<CommunityEmptyTitleProps>;
export default _default;
//# sourceMappingURL=CommunityEmptyTitle.d.ts.map