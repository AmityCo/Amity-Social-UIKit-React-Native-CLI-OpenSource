import React from 'react';
import { ComponentID, PageID } from '../../enum';
import { TouchableOpacityProps } from 'react-native';
type CancelCreateLivestreamButtonProps = TouchableOpacityProps & {
    pageId?: PageID;
    componentId?: ComponentID;
};
declare function CancelCreateLivestreamButton({ pageId, componentId, ...props }: CancelCreateLivestreamButtonProps): React.JSX.Element;
export default CancelCreateLivestreamButton;
//# sourceMappingURL=CancelCreateLivestreamButton.d.ts.map