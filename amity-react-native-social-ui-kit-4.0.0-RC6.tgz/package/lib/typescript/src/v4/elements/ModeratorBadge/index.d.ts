export { default } from './ModeratorBadge';
//# sourceMappingURL=index.d.ts.map