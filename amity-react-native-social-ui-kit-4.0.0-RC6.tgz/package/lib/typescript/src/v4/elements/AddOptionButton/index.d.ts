import React from 'react';
import { ComponentID, PageID } from '../../enum';
import { TouchableOpacityProps } from 'react-native';
type AddOptionButtonProps = TouchableOpacityProps & {
    pageId?: PageID;
    componentId?: ComponentID;
};
declare function AddOptionButton({ pageId, componentId, ...props }: AddOptionButtonProps): React.JSX.Element;
export default AddOptionButton;
//# sourceMappingURL=index.d.ts.map