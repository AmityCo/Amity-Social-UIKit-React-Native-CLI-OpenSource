import React from 'react';
import { PageID, ComponentID } from '../../enum';
type CategoryTitleProps = {
    title: string;
    pageId?: PageID;
    componentId?: ComponentID;
};
declare const _default: React.NamedExoticComponent<CategoryTitleProps>;
export default _default;
//# sourceMappingURL=CategoryTitle.d.ts.map