import React from 'react';
import { TouchableOpacityProps } from 'react-native';
import { ComponentID, ElementID, PageID } from '../../../v4/enum';
type CommunityAddMemberButtonProps = TouchableOpacityProps & {
    pageId?: PageID;
    componentId?: ComponentID;
    elementId?: ElementID;
};
declare function CommunityAddMemberButton({ style, pageId, componentId, elementId, ...props }: CommunityAddMemberButtonProps): React.JSX.Element;
export default CommunityAddMemberButton;
//# sourceMappingURL=CommunityAddMemberButton.d.ts.map