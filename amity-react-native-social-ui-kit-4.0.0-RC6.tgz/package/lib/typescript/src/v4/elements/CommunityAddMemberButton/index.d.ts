export { default } from './CommunityAddMemberButton';
//# sourceMappingURL=index.d.ts.map