import React from 'react';
import { PageID, ComponentID } from '../../enum';
type CategoryRowImageProps = {
    avatarFileId?: string;
    pageId?: PageID;
    componentId?: ComponentID;
};
declare const _default: React.NamedExoticComponent<CategoryRowImageProps>;
export default _default;
//# sourceMappingURL=CategoryRowImage.d.ts.map