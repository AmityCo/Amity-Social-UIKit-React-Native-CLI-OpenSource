import { FC } from 'react';
import { MyMD3Theme } from '../../../providers/amity-ui-kit-provider';
type ImageGalleryProps = {
    themeStyles?: MyMD3Theme;
    accessibilityId?: string;
    isLoading?: boolean;
    posts?: Amity.Post<'image'>[];
    onNextPage?: () => void;
};
declare const ImageGallery: FC<ImageGalleryProps>;
export default ImageGallery;
//# sourceMappingURL=ImageGallery.d.ts.map