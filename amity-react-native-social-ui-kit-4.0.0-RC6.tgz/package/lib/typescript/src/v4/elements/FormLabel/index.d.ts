import React from 'react';
import { TextProps } from 'react-native';
import { ComponentID, ElementID, PageID } from '../../enum/enumUIKitID';
type FormLabelProps = Partial<TextProps> & {
    optional?: boolean;
    pageId?: PageID;
    componentId?: ComponentID;
    elementId?: ElementID;
};
declare function FormLabel({ optional, pageId, componentId, elementId, ...props }: FormLabelProps): React.JSX.Element;
export default FormLabel;
//# sourceMappingURL=index.d.ts.map