import { FC } from 'react';
import { ComponentID, PageID } from '../../enum';
import { ViewProps } from 'react-native';
type CommunityDisplaynameProps = {
    communityName: string;
    pageId?: PageID;
    componentId?: ComponentID;
} & ViewProps;
declare const CommunityDisplayname: FC<CommunityDisplaynameProps>;
export default CommunityDisplayname;
//# sourceMappingURL=CommunityDisplayname.d.ts.map