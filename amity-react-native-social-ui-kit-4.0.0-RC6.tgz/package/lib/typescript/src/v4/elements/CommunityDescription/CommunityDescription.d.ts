import { FC } from 'react';
import { ComponentID, PageID } from '../../enum';
import { ViewProps } from 'react-native';
type CommunityDescriptionProps = ViewProps & {
    description?: string;
    pageId?: PageID;
    componentId?: ComponentID;
};
declare const CommunityDescription: FC<CommunityDescriptionProps>;
export default CommunityDescription;
//# sourceMappingURL=CommunityDescription.d.ts.map