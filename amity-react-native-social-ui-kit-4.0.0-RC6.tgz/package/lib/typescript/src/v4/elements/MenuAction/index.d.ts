export { default } from './MenuAction';
//# sourceMappingURL=index.d.ts.map