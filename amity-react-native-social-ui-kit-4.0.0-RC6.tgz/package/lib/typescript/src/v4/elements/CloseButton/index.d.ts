import React from 'react';
import { TouchableOpacityProps } from 'react-native';
import { XmlProps } from 'react-native-svg';
import { ComponentID, ElementID, PageID } from '../../../v4/enum';
type CloseButtonProps = TouchableOpacityProps & {
    pageId?: PageID;
    componentId?: ComponentID;
    elementId?: ElementID;
    iconProps?: Pick<XmlProps, 'width' | 'height' | 'color'>;
};
declare function CloseButton({ pageId, componentId, elementId, iconProps, ...props }: CloseButtonProps): React.JSX.Element;
export default CloseButton;
//# sourceMappingURL=index.d.ts.map