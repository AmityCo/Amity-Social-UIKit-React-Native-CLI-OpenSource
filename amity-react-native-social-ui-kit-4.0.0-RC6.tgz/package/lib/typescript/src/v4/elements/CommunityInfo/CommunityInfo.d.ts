import { FC } from 'react';
import { ComponentID, PageID } from '../../enum';
import { ViewProps } from 'react-native';
type CommunityInfoProps = ViewProps & {
    community: Amity.Community;
    pageId?: PageID;
    componentId?: ComponentID;
    onPress?: () => void;
};
declare const CommunityInfo: FC<CommunityInfoProps>;
export default CommunityInfo;
//# sourceMappingURL=CommunityInfo.d.ts.map