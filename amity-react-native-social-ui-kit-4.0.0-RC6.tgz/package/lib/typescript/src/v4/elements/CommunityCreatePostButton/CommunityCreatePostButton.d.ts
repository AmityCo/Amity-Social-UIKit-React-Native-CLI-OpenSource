import React from 'react';
import { TouchableOpacityProps } from 'react-native';
import { ComponentID, PageID } from '../../enum';
type CommunityCreatePostButtonProps = TouchableOpacityProps & {
    pageId?: PageID;
    componentId?: ComponentID;
};
declare function CommunityCreatePostButton({ pageId, componentId, ...props }: CommunityCreatePostButtonProps): React.JSX.Element;
export default CommunityCreatePostButton;
//# sourceMappingURL=CommunityCreatePostButton.d.ts.map