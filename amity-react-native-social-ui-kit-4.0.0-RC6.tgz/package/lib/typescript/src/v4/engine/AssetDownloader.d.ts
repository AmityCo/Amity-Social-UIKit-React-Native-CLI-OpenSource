export declare enum DownloadStatus {
    NOT_DOWNLOADED = -1,
    PENDING = 0,
    DOWNLOADING = 1,
    COMPLETED = 2,
    FAILED = 3
}
declare class AssetDownloader {
    #private;
    private client;
    private downloadJobs;
    private statusListeners;
    private constructor();
    static get instance(): AssetDownloader;
    /**
     * Enqueue a file for download
     * @param url URL to download
     * @returns The download ID (jobId)
     */
    enqueue(url: string): Promise<number>;
    /**
     * Get the file path for a downloaded asset
     */
    getFilePath(url: string): string;
    /**
     * Check if a file is existed
     */
    fileExists(url: string): Promise<boolean>;
    /**
     * Check if a file is downloaded
     */
    isDownloaded(url: string): Promise<boolean>;
    /**
     * Get the download status for a job
     */
    getDownloadStatus(downloadId: number): DownloadStatus;
    /**
     * Add a listener for download status changes
     */
    addStatusListener(url: string, listener: (status: DownloadStatus) => void): void;
    /**
     * Remove a listener
     */
    removeStatusListener(url: string, listener: (status: DownloadStatus) => void): void;
    /**
     * Notify all listeners for a URL about a status change
     */
    private notifyListeners;
    /**
     * Get a hash code from a string
     */
    private hashCode;
    /**
     * Delete a downloaded file for a specific URL
     * @param url URL of the asset to delete
     * @returns Promise resolving to boolean indicating success
     */
    deleteFile(url: string): Promise<boolean>;
    /**
     * Delete all downloaded files
     * @returns Promise resolving to boolean indicating success
     */
    deleteAllFiles(): Promise<boolean>;
}
export default AssetDownloader;
//# sourceMappingURL=AssetDownloader.d.ts.map