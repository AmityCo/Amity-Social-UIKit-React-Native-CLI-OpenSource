export type AdAsset = {
    fileUrl: string;
    downloadStatus: number;
    downloadId: number | null;
};
declare class AdAssetCache {
    #private;
    private storageKey;
    private pendingRequests;
    private memoryCache;
    private initialized;
    private initialize;
    static get instance(): AdAssetCache;
    getAllAdAssets(): Promise<AdAsset[]>;
    getAdAsset(fileUrl: string): Promise<AdAsset>;
    private _fetchAdAsset;
    insertAdAsset(asset: AdAsset): Promise<void>;
    updateDownloadId(fileUrl: string, downloadId: number): void;
    updateDownloadStatus(fileUrl: string, status: number): void;
    deleteAdAsset(fileUrl: string): void;
    deleteAll(): Promise<void>;
    private _saveTimeout;
    private _saveToStorage;
}
export default AdAssetCache;
//# sourceMappingURL=AdAssetCache.d.ts.map