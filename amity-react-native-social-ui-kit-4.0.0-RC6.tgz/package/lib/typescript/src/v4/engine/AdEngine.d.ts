export declare class AdEngine {
    #private;
    private isLoading;
    private ads;
    private settings;
    private subscribers;
    private constructor();
    static get instance(): AdEngine;
    onNetworkAdsData(callback: (networkAds: Amity.NetworkAds | null) => void): void;
    private clearAllCache;
    private consumeNetworkAds;
    private generateAssets;
    private diffAssets;
    private refreshDownloadStatuses;
    private getAdFrequency;
    private getUrlByPlacement;
    getLastSeen(adId?: string): number | void;
    markClicked(ad: Amity.Ad, placement: Amity.AdPlacement): void;
    markSeen(ad: Amity.Ad, placement: Amity.AdPlacement): void;
    getAdFrequencyByPlacement(placement: Amity.AdPlacement): Amity.AdFrequency;
    getRecommendedAds({ placement, count, communityId, }: {
        placement: Amity.AdPlacement;
        count: number;
        communityId?: string;
    }): Promise<any[]>;
    private getApplicableAds;
}
export default AdEngine;
//# sourceMappingURL=AdEngine.d.ts.map