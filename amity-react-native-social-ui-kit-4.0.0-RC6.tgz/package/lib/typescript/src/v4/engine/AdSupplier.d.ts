export declare class AdSupplier {
    #private;
    private constructor();
    static get instance(): AdSupplier;
    recommendedAds({ ads, count, communityId, }: {
        ads: Amity.Ad[];
        placement: Amity.AdPlacement;
        count: number;
        communityId?: string;
    }): any[];
    private calculateImpressionAges;
    private weightedRandomChoice;
    private selectAdsByWeightedRandomChoice;
}
//# sourceMappingURL=AdSupplier.d.ts.map