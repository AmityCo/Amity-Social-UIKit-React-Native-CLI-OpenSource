import React from 'react';
export type FeedRefType = {
    handleLoadMore: () => void;
};
type CommunityHomePageType = {
    defaultCommunityId: string;
};
export default function CommunityHome({ defaultCommunityId, }: CommunityHomePageType): React.JSX.Element;
export {};
//# sourceMappingURL=index.d.ts.map