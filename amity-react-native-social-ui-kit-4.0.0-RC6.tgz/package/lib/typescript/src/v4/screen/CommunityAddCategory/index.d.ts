import React from 'react';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { RootStackParamList } from '../../../v4/routes/RouteParamList';
type CommunityAddCategoryProps = NativeStackScreenProps<RootStackParamList, 'CommunityAddCategory'>;
declare function CommunityAddCategory(_: CommunityAddCategoryProps): React.JSX.Element;
export default CommunityAddCategory;
//# sourceMappingURL=index.d.ts.map