import React from 'react';
import { RootStackParamList } from '../../../v4/routes/RouteParamList';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
type CommunityNotificationSettingProps = NativeStackScreenProps<RootStackParamList, 'CommunityNotificationSetting'>;
declare function CommunityNotificationSetting(_: CommunityNotificationSettingProps): React.JSX.Element;
export default CommunityNotificationSetting;
//# sourceMappingURL=index.d.ts.map