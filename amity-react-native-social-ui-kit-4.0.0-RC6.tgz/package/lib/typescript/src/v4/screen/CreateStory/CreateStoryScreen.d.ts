import React from 'react';
declare const CreateStoryScreen: ({ navigation, route }: {
    navigation: any;
    route: any;
}) => React.JSX.Element;
export default CreateStoryScreen;
//# sourceMappingURL=CreateStoryScreen.d.ts.map