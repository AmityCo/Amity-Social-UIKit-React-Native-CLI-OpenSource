import React from 'react';
import { TabName } from '../../../enum/tabNameState';
type FollowerListItemType = {
    userId: string;
    currentProfileId: string;
    activeTab: TabName;
};
declare const _default: React.NamedExoticComponent<FollowerListItemType>;
export default _default;
//# sourceMappingURL=FollowerListItem.d.ts.map