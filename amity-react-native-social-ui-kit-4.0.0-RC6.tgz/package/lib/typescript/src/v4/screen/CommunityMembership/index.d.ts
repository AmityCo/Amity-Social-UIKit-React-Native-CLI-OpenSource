import React from 'react';
import { RootStackParamList } from '../../../v4/routes/RouteParamList';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
type CommunityMembershipProps = NativeStackScreenProps<RootStackParamList, 'CommunityMembership'>;
declare function CommunityMembership(_: CommunityMembershipProps): React.JSX.Element;
export default CommunityMembership;
//# sourceMappingURL=index.d.ts.map