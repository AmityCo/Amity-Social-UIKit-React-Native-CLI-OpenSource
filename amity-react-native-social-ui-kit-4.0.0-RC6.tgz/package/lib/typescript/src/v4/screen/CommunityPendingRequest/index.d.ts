import React from 'react';
import { RootStackParamList } from '../../../v4/routes/RouteParamList';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
type CommunityPendingRequestProps = NativeStackScreenProps<RootStackParamList, 'CommunityPendingRequest'>;
declare function CommunityPendingRequest(_: CommunityPendingRequestProps): React.JSX.Element;
export default CommunityPendingRequest;
//# sourceMappingURL=index.d.ts.map