import React from 'react';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { RootStackParamList } from '../../../v4/routes/RouteParamList';
type CommunityAddMemberProps = NativeStackScreenProps<RootStackParamList, 'CommunityAddMember'>;
declare function CommunityAddMember(_: CommunityAddMemberProps): React.JSX.Element;
export default CommunityAddMember;
//# sourceMappingURL=index.d.ts.map