export { default } from './AmityCommunityPostPermissionPage';
//# sourceMappingURL=index.d.ts.map