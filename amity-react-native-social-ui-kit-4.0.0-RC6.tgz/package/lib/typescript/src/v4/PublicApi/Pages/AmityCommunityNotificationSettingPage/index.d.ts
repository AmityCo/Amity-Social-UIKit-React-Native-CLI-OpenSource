export { default } from './AmityCommunityNotificationSettingPage';
//# sourceMappingURL=index.d.ts.map