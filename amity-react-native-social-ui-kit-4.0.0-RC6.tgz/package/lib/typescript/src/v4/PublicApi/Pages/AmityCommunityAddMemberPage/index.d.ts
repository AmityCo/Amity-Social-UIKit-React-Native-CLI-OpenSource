export { default } from './AmityCommunityAddMemberPage';
//# sourceMappingURL=index.d.ts.map