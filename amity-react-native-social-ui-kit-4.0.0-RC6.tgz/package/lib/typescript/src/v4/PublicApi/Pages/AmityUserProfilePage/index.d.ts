export { default } from './AmityUserProfilePage';
//# sourceMappingURL=index.d.ts.map