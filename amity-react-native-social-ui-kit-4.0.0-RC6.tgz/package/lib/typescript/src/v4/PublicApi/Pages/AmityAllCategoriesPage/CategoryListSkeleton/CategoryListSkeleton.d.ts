import React from 'react';
import { MyMD3Theme } from '../../../../../providers/amity-ui-kit-provider';
type CategoryListSkeletonProps = {
    themeStyle?: MyMD3Theme;
    amount?: number;
};
declare const _default: React.NamedExoticComponent<CategoryListSkeletonProps>;
export default _default;
//# sourceMappingURL=CategoryListSkeleton.d.ts.map