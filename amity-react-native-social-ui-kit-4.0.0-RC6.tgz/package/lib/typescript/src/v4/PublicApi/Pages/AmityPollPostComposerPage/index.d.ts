export { default } from './AmityPollPostComposerPage';
//# sourceMappingURL=index.d.ts.map