import React from 'react';
import { NextOrPrevious } from '../../../component/StoryKit';
interface IAmityViewStoryPage {
    targetType: Amity.StoryTargetType;
    targetId: string;
    currentPage?: number;
    index?: number;
    onFinish?: (state?: NextOrPrevious, targetId?: string) => void;
    onPressCommunityName?: () => void;
    onPressAvatar?: () => void;
}
declare const _default: React.NamedExoticComponent<IAmityViewStoryPage>;
export default _default;
//# sourceMappingURL=AmityViewStoryPage.d.ts.map