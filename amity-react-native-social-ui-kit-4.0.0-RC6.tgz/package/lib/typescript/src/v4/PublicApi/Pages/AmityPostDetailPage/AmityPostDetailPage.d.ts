import React from 'react';
import { AmityPostCategory } from '../../../../v4/enum/AmityPostContentComponentStyle';
type AmityPostDetailPageType = {
    postId: Amity.Post['postId'];
    isFromComponent?: boolean;
    showEndPopup?: boolean;
    category?: AmityPostCategory;
};
declare const _default: React.NamedExoticComponent<AmityPostDetailPageType>;
export default _default;
//# sourceMappingURL=AmityPostDetailPage.d.ts.map