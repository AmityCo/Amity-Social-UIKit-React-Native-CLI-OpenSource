import React from 'react';
declare function AmityLiveStreamPlayerPage(): React.JSX.Element;
export default AmityLiveStreamPlayerPage;
//# sourceMappingURL=AmityLivestreamPlayerPage.d.ts.map