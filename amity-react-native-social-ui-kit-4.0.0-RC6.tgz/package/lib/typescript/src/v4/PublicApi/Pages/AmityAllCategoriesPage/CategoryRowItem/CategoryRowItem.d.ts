import React from 'react';
import { PageID } from '../../../../enum';
type CategoryRowItemProps = {
    pageId?: PageID;
    category: Amity.Category;
};
declare const _default: React.NamedExoticComponent<CategoryRowItemProps>;
export default _default;
//# sourceMappingURL=CategoryRowItem.d.ts.map