import React from 'react';
import { TSearchItem } from '../../../../hooks/useSearch';
import { BottomSheetMethods } from '@devvie/bottom-sheet';
type PollDurationValue = {
    value: number;
    label: string;
};
export declare const durationOptions: PollDurationValue[];
export declare const androidDurationOptions: PollDurationValue[];
export type PollPostComposerContextType = {
    loading: boolean;
    setLoading: (loading: boolean) => void;
    isMultipleOption: boolean;
    setIsMultipleOption: (value: boolean) => void;
    pollOptions: Pick<Amity.PollAnswer, 'data' | 'dataType'>[];
    setPollOptions: React.Dispatch<React.SetStateAction<Pick<Amity.PollAnswer, 'data' | 'dataType'>[]>>;
    pollQuestion: string;
    setPollQuestion: (question: string) => void;
    mentionUsers: TSearchItem[];
    setMentionUsers: React.Dispatch<React.SetStateAction<TSearchItem[]>>;
    mentionPosition: any[];
    setMentionPosition: React.Dispatch<React.SetStateAction<any[]>>;
    duration: PollDurationValue;
    setDuration: (duration: PollDurationValue) => void;
    bottomSheetRef: React.RefObject<BottomSheetMethods>;
    isShowingDatePicker?: boolean;
    setIsShowingDatePicker?: (isShowing: boolean) => void;
    isTimePickerShown?: boolean;
    setIsTimePickerShown?: (isShown: boolean) => void;
    selectedDate?: Date;
    setSelectedDate?: (date: Date) => void;
    selectedTime?: Date;
    setSelectedTime?: (time: Date) => void;
};
export declare const usePollPostComposerContext: () => PollPostComposerContextType;
declare const AmityPollPostComposerPage: () => React.JSX.Element;
export default AmityPollPostComposerPage;
//# sourceMappingURL=AmityPollPostComposerPage.d.ts.map