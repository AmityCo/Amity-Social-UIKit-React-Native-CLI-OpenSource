import React from 'react';
type AmityCommunityStoriesNotificationSettingPageProps = {
    community: Amity.Community;
};
declare const AmityCommunityStoriesNotificationSettingPage: ({ community, }: AmityCommunityStoriesNotificationSettingPageProps) => React.JSX.Element;
export default AmityCommunityStoriesNotificationSettingPage;
//# sourceMappingURL=AmityCommunityStoriesNotificationSettingPage.d.ts.map