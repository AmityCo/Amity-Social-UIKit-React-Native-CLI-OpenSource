export { default } from './AmityCommunityPendingRequestPage';
//# sourceMappingURL=index.d.ts.map