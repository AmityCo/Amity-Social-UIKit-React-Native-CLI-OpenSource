export { default } from './AmityCommunitySettingPage';
//# sourceMappingURL=index.d.ts.map