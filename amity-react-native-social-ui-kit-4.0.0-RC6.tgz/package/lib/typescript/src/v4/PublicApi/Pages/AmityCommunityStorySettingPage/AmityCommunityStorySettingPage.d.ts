import React from 'react';
type AmityCommunityStorySettingPageProps = {
    community: Amity.Community;
};
declare const AmityCommunityStorySettingPage: ({ community, }: AmityCommunityStorySettingPageProps) => React.JSX.Element;
export default AmityCommunityStorySettingPage;
//# sourceMappingURL=AmityCommunityStorySettingPage.d.ts.map