export { default } from './AmityCommunityAddCategoryPage';
//# sourceMappingURL=index.d.ts.map