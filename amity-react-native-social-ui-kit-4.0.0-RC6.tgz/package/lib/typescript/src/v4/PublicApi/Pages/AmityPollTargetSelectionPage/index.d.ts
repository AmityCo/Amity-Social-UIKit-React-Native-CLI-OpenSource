export { default } from './AmityPollTargetSelectionPage';
//# sourceMappingURL=index.d.ts.map