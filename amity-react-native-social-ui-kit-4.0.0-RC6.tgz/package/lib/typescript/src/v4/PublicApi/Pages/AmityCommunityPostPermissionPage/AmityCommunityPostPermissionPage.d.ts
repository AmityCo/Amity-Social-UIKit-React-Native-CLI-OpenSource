import React from 'react';
type AmityCommunityPostPermissionPageProps = {
    community: Amity.Community;
};
declare const AmityCommunityPostPermissionPage: ({ community, }: AmityCommunityPostPermissionPageProps) => React.JSX.Element;
export default AmityCommunityPostPermissionPage;
//# sourceMappingURL=AmityCommunityPostPermissionPage.d.ts.map