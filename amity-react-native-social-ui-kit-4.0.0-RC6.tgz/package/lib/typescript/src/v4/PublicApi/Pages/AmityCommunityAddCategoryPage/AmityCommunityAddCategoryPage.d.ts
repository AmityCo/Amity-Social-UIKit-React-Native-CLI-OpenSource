import React from 'react';
declare const AmityCommunityAddCategoryPage: () => React.JSX.Element;
export default AmityCommunityAddCategoryPage;
//# sourceMappingURL=AmityCommunityAddCategoryPage.d.ts.map