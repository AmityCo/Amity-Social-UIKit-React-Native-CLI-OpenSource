import React from 'react';
declare const AmityCommunityAddMemberPage: () => React.JSX.Element;
export default AmityCommunityAddMemberPage;
//# sourceMappingURL=AmityCommunityAddMemberPage.d.ts.map