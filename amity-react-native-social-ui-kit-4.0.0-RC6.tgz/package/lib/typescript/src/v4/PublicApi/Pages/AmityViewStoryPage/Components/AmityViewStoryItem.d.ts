import React from 'react';
import { NextOrPrevious } from '../../../../component/StoryKit';
interface IAmityViewStoryItem {
    communityData: Amity.Community;
    communityAvatar: string;
    storyData: IStoryData[];
    hasStoryImpressionPermission: boolean;
    close: (state: NextOrPrevious) => void;
    onClose: () => void;
    setCurrent: (arg: number) => void;
    current: number;
    hasStoryPermission: boolean;
    onPressAvatar?: () => void;
    onPressCommunityName?: () => void;
}
interface IStoryData extends Amity.Story {
    finish: number;
}
declare const _default: React.NamedExoticComponent<IAmityViewStoryItem>;
export default _default;
//# sourceMappingURL=AmityViewStoryItem.d.ts.map