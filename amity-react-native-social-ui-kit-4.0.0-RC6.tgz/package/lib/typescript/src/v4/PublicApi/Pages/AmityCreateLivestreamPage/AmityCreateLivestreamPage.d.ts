import React from 'react';
declare function AmityCreateLivestreamPage(): React.JSX.Element;
export default AmityCreateLivestreamPage;
//# sourceMappingURL=AmityCreateLivestreamPage.d.ts.map