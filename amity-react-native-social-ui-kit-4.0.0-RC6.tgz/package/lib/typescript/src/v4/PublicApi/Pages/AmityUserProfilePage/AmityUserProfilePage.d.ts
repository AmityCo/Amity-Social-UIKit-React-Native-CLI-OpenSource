import React from 'react';
type UserProfilePageProps = {
    userId: string;
    isFromComponent?: boolean;
    isShowBackButton?: boolean;
};
declare function UserProfile({ userId, isFromComponent, isShowBackButton, }: UserProfilePageProps): React.JSX.Element;
export default UserProfile;
//# sourceMappingURL=AmityUserProfilePage.d.ts.map