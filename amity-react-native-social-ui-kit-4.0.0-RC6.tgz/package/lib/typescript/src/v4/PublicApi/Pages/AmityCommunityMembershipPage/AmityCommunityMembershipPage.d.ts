import React from 'react';
type AmityCommunityMembershipPageProps = {
    community: Amity.Community;
};
declare const AmityCommunityMembershipPage: ({ community, }: AmityCommunityMembershipPageProps) => React.JSX.Element;
export default AmityCommunityMembershipPage;
//# sourceMappingURL=AmityCommunityMembershipPage.d.ts.map