export { default } from './AmityLivestreamTerminatedPage';
//# sourceMappingURL=index.d.ts.map