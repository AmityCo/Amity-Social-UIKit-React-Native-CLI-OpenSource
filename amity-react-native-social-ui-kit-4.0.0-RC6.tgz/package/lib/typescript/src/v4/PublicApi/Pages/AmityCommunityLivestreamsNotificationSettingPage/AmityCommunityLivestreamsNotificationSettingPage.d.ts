import React from 'react';
type AmityCommunityLivestreamsNotificationSettingPageProps = {
    community: Amity.Community;
};
declare const AmityCommunityLivestreamsNotificationSettingPage: ({ community, }: AmityCommunityLivestreamsNotificationSettingPageProps) => React.JSX.Element;
export default AmityCommunityLivestreamsNotificationSettingPage;
//# sourceMappingURL=AmityCommunityLivestreamsNotificationSettingPage.d.ts.map