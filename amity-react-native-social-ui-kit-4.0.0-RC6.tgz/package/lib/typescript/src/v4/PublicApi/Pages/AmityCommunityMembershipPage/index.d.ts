export { default } from './AmityCommunityMembershipPage';
//# sourceMappingURL=index.d.ts.map