import React from 'react';
type ICommunityProfilePage = {
    defaultCommunityId?: string;
};
declare const _default: React.NamedExoticComponent<ICommunityProfilePage>;
export default _default;
//# sourceMappingURL=AmityCommunityProfilePage.d.ts.map