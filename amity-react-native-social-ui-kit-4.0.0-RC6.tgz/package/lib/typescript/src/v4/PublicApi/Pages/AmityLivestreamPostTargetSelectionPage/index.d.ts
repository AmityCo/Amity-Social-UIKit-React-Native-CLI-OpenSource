export { default } from './AmityLivestreamPostTargetSelectionPage';
//# sourceMappingURL=index.d.ts.map