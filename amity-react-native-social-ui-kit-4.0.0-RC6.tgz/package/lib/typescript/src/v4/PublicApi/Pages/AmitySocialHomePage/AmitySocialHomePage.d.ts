import * as React from 'react';
declare const _default: React.MemoExoticComponent<() => React.JSX.Element>;
export default _default;
//# sourceMappingURL=AmitySocialHomePage.d.ts.map