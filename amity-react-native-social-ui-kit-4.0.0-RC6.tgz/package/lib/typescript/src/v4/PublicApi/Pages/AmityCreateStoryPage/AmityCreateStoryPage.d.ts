import React from 'react';
interface ICreateStoryPage {
    targetId: string;
    targetType: Amity.StoryTargetType;
    onCreateStory?: () => void;
    onDiscardStory?: () => void;
}
declare const _default: React.NamedExoticComponent<ICreateStoryPage>;
export default _default;
//# sourceMappingURL=AmityCreateStoryPage.d.ts.map