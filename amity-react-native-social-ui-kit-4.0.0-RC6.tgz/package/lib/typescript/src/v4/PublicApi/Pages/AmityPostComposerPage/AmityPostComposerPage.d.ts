import React from 'react';
import { AmityPostComposerPageType } from '../../types';
declare const _default: React.NamedExoticComponent<AmityPostComposerPageType>;
export default _default;
//# sourceMappingURL=AmityPostComposerPage.d.ts.map