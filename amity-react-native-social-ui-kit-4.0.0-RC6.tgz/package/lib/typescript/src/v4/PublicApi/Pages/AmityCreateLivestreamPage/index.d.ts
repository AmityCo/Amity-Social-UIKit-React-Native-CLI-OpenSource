export { default } from './AmityCreateLivestreamPage';
//# sourceMappingURL=index.d.ts.map