import React from 'react';
type AmityCommunityCommentsNotificationSettingPageProps = {
    community: Amity.Community;
};
declare const AmityCommunityCommentsNotificationSettingPage: ({ community, }: AmityCommunityCommentsNotificationSettingPageProps) => React.JSX.Element;
export default AmityCommunityCommentsNotificationSettingPage;
//# sourceMappingURL=AmityCommunityCommentsNotificationSettingPage.d.ts.map