import React from 'react';
type AmityCommunitySettingPageProps = {
    community: Amity.Community;
};
declare const AmityCommunitySettingPage: ({ community, }: AmityCommunitySettingPageProps) => React.JSX.Element;
export default AmityCommunitySettingPage;
//# sourceMappingURL=AmityCommunitySettingPage.d.ts.map