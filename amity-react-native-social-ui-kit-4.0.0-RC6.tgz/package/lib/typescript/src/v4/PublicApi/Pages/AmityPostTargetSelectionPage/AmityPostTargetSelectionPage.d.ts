import React from 'react';
import { AmityPostTargetSelectionPageType } from '../../../../v4/enum';
declare const _default: React.MemoExoticComponent<({ postType, }: {
    postType: AmityPostTargetSelectionPageType;
}) => React.JSX.Element>;
export default _default;
//# sourceMappingURL=AmityPostTargetSelectionPage.d.ts.map