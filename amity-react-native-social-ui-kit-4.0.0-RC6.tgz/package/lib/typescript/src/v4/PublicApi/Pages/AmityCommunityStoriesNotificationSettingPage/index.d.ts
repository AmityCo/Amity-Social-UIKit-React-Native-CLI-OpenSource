export { default } from './AmityCommunityStoriesNotificationSettingPage';
//# sourceMappingURL=index.d.ts.map