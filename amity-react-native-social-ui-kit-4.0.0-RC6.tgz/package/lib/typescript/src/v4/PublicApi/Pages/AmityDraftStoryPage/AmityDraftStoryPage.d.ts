import React from 'react';
import { IAmityDraftStoryPage } from '../../types';
declare const _default: React.NamedExoticComponent<IAmityDraftStoryPage>;
export default _default;
//# sourceMappingURL=AmityDraftStoryPage.d.ts.map