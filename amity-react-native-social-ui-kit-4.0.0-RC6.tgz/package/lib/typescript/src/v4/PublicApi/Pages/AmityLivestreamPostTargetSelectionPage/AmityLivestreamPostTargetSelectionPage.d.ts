import React from 'react';
declare const _default: React.MemoExoticComponent<() => React.JSX.Element>;
export default _default;
//# sourceMappingURL=AmityLivestreamPostTargetSelectionPage.d.ts.map