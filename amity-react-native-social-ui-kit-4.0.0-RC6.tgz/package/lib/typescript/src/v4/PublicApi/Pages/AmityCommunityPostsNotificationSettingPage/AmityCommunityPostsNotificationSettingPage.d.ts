import React from 'react';
type AmityCommunityPostsNotificationSettingPageProps = {
    community: Amity.Community;
};
declare const AmityCommunityPostsNotificationSettingPage: ({ community, }: AmityCommunityPostsNotificationSettingPageProps) => React.JSX.Element;
export default AmityCommunityPostsNotificationSettingPage;
//# sourceMappingURL=AmityCommunityPostsNotificationSettingPage.d.ts.map