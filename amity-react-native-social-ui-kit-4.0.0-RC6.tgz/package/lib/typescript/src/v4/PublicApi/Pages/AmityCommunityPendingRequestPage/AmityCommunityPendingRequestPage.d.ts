import React from 'react';
type AmityCommunityPendingRequestPageProps = {
    community: Amity.Community;
};
declare const AmityCommunityPendingRequestPage: ({ community, }: AmityCommunityPendingRequestPageProps) => React.JSX.Element;
export default AmityCommunityPendingRequestPage;
//# sourceMappingURL=AmityCommunityPendingRequestPage.d.ts.map