export { default } from './AmityLivestreamPlayerPage';
//# sourceMappingURL=index.d.ts.map