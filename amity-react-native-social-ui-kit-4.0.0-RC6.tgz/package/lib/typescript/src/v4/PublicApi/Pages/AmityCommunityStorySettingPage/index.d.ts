export { default } from './AmityCommunityStorySettingPage';
//# sourceMappingURL=index.d.ts.map