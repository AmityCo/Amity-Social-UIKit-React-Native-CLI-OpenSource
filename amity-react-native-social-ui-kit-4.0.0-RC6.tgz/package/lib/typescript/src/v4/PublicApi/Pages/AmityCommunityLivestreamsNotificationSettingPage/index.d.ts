export { default } from './AmityCommunityLivestreamsNotificationSettingPage';
//# sourceMappingURL=index.d.ts.map