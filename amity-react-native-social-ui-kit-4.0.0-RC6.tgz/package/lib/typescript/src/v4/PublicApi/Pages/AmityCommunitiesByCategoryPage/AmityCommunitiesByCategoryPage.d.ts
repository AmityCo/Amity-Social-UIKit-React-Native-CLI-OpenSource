import React from 'react';
declare const _default: React.MemoExoticComponent<({ route }: any) => React.JSX.Element>;
export default _default;
//# sourceMappingURL=AmityCommunitiesByCategoryPage.d.ts.map