import React from 'react';
declare function AmityLivestreamTerminatedPage(): React.JSX.Element;
export default AmityLivestreamTerminatedPage;
//# sourceMappingURL=AmityLivestreamTerminatedPage.d.ts.map