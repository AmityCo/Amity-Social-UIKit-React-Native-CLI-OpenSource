import React from 'react';
interface IHyperLinkConfig {
    isVisibleModal: boolean;
    hyperlinkItem?: {
        url: string;
        customText: string;
    };
    setIsVisibleModal: (arg: boolean) => void;
    onHyperLinkSubmit: (arg?: {
        url: string;
        customText: string;
    }) => void;
}
declare const _default: React.NamedExoticComponent<IHyperLinkConfig>;
export default _default;
//# sourceMappingURL=HyperLinkConfig.d.ts.map