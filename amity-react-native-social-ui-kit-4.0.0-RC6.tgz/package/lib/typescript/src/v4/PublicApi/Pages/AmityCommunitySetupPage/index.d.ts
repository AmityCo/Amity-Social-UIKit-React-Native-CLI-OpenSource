import React from 'react';
export declare enum AmityCommunitySetupPageMode {
    CREATE = "create",
    EDIT = "edit"
}
type CreateCommunityProps = {
    mode: AmityCommunitySetupPageMode.CREATE;
};
type EditCommunityProps = {
    mode: AmityCommunitySetupPageMode.EDIT;
    community: Amity.Community;
};
export type CommunityMember = {
    userId: string;
    displayName: string;
};
export type AmityCommunitySetupPageProps = CreateCommunityProps | EditCommunityProps;
declare function AmityCommunitySetupPage(props: AmityCommunitySetupPageProps): React.JSX.Element;
export default AmityCommunitySetupPage;
//# sourceMappingURL=index.d.ts.map