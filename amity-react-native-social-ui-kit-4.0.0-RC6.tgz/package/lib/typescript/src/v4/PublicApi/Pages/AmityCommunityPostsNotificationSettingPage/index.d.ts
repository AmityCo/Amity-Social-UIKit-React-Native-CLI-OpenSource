export { default } from './AmityCommunityPostsNotificationSettingPage';
//# sourceMappingURL=index.d.ts.map