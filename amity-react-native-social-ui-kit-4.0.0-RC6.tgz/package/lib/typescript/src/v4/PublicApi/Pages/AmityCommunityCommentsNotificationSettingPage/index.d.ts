export { default } from './AmityCommunityCommentsNotificationSettingPage';
//# sourceMappingURL=index.d.ts.map