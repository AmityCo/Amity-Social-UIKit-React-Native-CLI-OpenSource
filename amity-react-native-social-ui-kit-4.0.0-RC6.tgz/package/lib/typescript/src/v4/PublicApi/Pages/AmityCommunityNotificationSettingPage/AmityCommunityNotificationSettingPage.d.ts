import React from 'react';
type AmityCommunityStorySettingPageProps = {
    community: Amity.Community;
};
declare const AmityCommunityStorySettingPage: ({ community, }: AmityCommunityStorySettingPageProps) => React.JSX.Element;
export default AmityCommunityStorySettingPage;
//# sourceMappingURL=AmityCommunityNotificationSettingPage.d.ts.map