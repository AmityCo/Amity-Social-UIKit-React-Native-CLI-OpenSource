import { PageID } from '../../../enum/enumUIKitID';
type AmityThumbnailActionComponentProps = {
    pageId?: PageID;
    onChangeThumbnail?: () => void;
    onDeleteThumbnail?: () => void;
};
declare const AmityThumbnailActionComponent: ({ onChangeThumbnail, onDeleteThumbnail, pageId, }: AmityThumbnailActionComponentProps) => JSX.Element;
export default AmityThumbnailActionComponent;
//# sourceMappingURL=AmityThumbnailActionComponent.d.ts.map