import React from 'react';
import { PageID } from '../../../enum';
type AmityExploreComponentProps = {
    pageId?: PageID;
};
declare const AmityExploreComponent: React.FC<AmityExploreComponentProps>;
export default AmityExploreComponent;
//# sourceMappingURL=AmityExploreComponent.d.ts.map