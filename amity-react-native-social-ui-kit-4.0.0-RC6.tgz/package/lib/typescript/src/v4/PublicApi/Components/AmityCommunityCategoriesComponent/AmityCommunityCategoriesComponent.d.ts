import React from 'react';
import { PageID } from '../../../enum';
type AmityCommunityCategoriesComponentProps = {
    pageId?: PageID;
};
declare const _default: React.NamedExoticComponent<AmityCommunityCategoriesComponentProps>;
export default _default;
//# sourceMappingURL=AmityCommunityCategoriesComponent.d.ts.map