import React from 'react';
type ExploreCommunityButtonType = {
    onPressExploreCommunity?: () => void;
};
declare const _default: React.NamedExoticComponent<ExploreCommunityButtonType>;
export default _default;
//# sourceMappingURL=ExploreCommunityButton.d.ts.map