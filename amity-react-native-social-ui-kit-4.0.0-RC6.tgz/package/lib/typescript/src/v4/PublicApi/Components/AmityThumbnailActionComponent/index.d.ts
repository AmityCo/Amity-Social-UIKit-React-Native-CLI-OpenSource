export { default as AmityThumbnailActionComponent } from './AmityThumbnailActionComponent';
//# sourceMappingURL=index.d.ts.map