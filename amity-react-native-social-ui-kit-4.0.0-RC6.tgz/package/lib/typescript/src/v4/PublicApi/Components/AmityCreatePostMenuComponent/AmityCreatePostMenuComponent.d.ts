import React from 'react';
import { ComponentID, PageID } from '../../../enum/enumUIKitID';
interface AmityCreatePostMenuComponentProps {
    pageId?: PageID;
    componentId?: ComponentID;
}
declare const _default: React.MemoExoticComponent<({ pageId, componentId, }: AmityCreatePostMenuComponentProps) => JSX.Element>;
export default _default;
//# sourceMappingURL=AmityCreatePostMenuComponent.d.ts.map