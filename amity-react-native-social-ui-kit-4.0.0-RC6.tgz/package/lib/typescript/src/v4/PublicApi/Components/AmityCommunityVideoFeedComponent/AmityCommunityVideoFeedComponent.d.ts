import React from 'react';
import { PageID } from '../../../enum';
import { AmityCommunityFeedRef } from '../AmityCommunityFeedComponent/AmityCommunityFeedComponent';
type AmityCommunityVideoFeedComponentProps = {
    pageId?: PageID;
    communityId: string;
};
declare const _default: React.MemoExoticComponent<React.ForwardRefExoticComponent<AmityCommunityVideoFeedComponentProps & React.RefAttributes<AmityCommunityFeedRef>>>;
export default _default;
//# sourceMappingURL=AmityCommunityVideoFeedComponent.d.ts.map