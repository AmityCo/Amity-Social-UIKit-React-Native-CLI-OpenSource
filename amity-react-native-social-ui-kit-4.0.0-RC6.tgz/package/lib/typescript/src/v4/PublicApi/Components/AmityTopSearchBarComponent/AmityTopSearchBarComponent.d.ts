import React from 'react';
import { TabName } from '../../../enum';
type AmityTopSearchBarComponentType = {
    setSearchValue: (arg: string) => void;
    searchType: TabName;
};
declare const _default: React.MemoExoticComponent<({ setSearchValue, searchType, }: AmityTopSearchBarComponentType) => React.JSX.Element>;
export default _default;
//# sourceMappingURL=AmityTopSearchBarComponent.d.ts.map