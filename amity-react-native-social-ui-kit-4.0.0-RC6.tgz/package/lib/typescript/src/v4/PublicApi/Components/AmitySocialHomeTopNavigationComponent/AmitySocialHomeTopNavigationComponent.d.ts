import React from 'react';
type AmitySocialHomeTopNavigationComponentType = {
    activeTab: string;
};
declare const _default: React.NamedExoticComponent<AmitySocialHomeTopNavigationComponentType>;
export default _default;
//# sourceMappingURL=AmitySocialHomeTopNavigationComponent.d.ts.map