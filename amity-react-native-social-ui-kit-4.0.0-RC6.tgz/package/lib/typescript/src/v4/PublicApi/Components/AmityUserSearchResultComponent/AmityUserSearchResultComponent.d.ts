import React from 'react';
import { PageID } from '../../../enum';
type AmityUserSearchResultComponentType = {
    pageId?: PageID;
    searchResult: Amity.Community[] & Amity.User[];
    onNextPage: () => void;
};
declare const _default: React.NamedExoticComponent<AmityUserSearchResultComponentType>;
export default _default;
//# sourceMappingURL=AmityUserSearchResultComponent.d.ts.map