import React from 'react';
type AmityReactionListComponentType = {
    referenceId: string;
    referenceType: Amity.ReactableType;
    isModalVisible: boolean;
    onCloseModal: () => void;
};
declare const _default: React.NamedExoticComponent<AmityReactionListComponentType>;
export default _default;
//# sourceMappingURL=AmityReactionListComponent.d.ts.map