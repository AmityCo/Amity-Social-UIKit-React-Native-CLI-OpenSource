import React from 'react';
import { mediaAttachment } from '../../../enum';
type AmityDetailedMediaAttachmentComponentType = {
    onPressCamera: () => void;
    onPressImage: () => void;
    onPressVideo: () => void;
    chosenMediaType?: mediaAttachment;
};
declare const _default: React.NamedExoticComponent<AmityDetailedMediaAttachmentComponentType>;
export default _default;
//# sourceMappingURL=AmityDetailedMediaAttachmentComponent.d.ts.map