import React from 'react';
import { PostTargetType } from '../../../../enum/postTargetType';
type AmityPostEngagementContentComponentProps = {
    postId: string;
    targetId: string;
    targetType: PostTargetType;
    postType?: Amity.CommentReferenceType;
};
declare function AmityPostEngagementContentComponent({ postId, targetId, targetType, postType, }: AmityPostEngagementContentComponentProps): React.JSX.Element;
export default AmityPostEngagementContentComponent;
//# sourceMappingURL=AmityPostEngagementContentComponent.d.ts.map