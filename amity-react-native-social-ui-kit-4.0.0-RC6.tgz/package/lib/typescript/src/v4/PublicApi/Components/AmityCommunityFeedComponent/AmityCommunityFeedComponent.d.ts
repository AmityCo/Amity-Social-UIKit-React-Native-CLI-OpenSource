import React from 'react';
import { PageID } from '../../../../v4/enum';
export interface AmityCommunityFeedRef {
    handleLoadMore: () => void;
}
type AmityCommunityFeedComponentProps = {
    pageId?: PageID;
    communityId: string;
};
declare const AmityCommunityFeedComponent: React.ForwardRefExoticComponent<AmityCommunityFeedComponentProps & React.RefAttributes<AmityCommunityFeedRef>>;
export default AmityCommunityFeedComponent;
//# sourceMappingURL=AmityCommunityFeedComponent.d.ts.map