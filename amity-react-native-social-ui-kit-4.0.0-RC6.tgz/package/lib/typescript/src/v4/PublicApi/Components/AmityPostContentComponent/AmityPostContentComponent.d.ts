import React from 'react';
import { PageID } from '../../../enum';
import { AmityPostCategory, AmityPostContentComponentStyleEnum } from '../../../enum/AmityPostContentComponentStyle';
type AmityPostContentComponentProps = {
    post: Amity.Post & {
        structureType?: string;
    };
    pageId?: PageID;
    AmityPostContentComponentStyle?: AmityPostContentComponentStyleEnum;
    isCommunityNameShown?: boolean;
    showedAllOptions?: boolean;
    category?: AmityPostCategory;
};
export interface MediaUri {
    uri: string;
}
export interface IVideoPost {
    thumbnailFileId: string;
    videoFileId: {
        original: string;
    };
}
declare const _default: React.NamedExoticComponent<AmityPostContentComponentProps>;
export default _default;
//# sourceMappingURL=AmityPostContentComponent.d.ts.map