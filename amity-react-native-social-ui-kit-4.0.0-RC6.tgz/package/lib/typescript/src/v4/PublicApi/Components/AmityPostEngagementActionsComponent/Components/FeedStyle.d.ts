import React from 'react';
import { AmityPostEngagementActionsSubComponentType } from './type';
declare const _default: React.NamedExoticComponent<AmityPostEngagementActionsSubComponentType>;
export default _default;
//# sourceMappingURL=FeedStyle.d.ts.map