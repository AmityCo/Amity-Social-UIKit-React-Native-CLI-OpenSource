export declare const AmityPostEngagementActionsSubComponent: {
    DetailStyle: import("react").NamedExoticComponent<import("./type").AmityPostEngagementActionsSubComponentType>;
    FeedStyle: import("react").NamedExoticComponent<import("./type").AmityPostEngagementActionsSubComponentType>;
};
//# sourceMappingURL=index.d.ts.map