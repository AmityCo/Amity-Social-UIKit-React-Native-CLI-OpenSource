import React from 'react';
import { PageID } from '../../../enum';
import { AmityCommunityFeedRef } from '../AmityCommunityFeedComponent/AmityCommunityFeedComponent';
type AmityCommunityImageFeedComponentProps = {
    pageId?: PageID;
    communityId: string;
};
declare const _default: React.MemoExoticComponent<React.ForwardRefExoticComponent<AmityCommunityImageFeedComponentProps & React.RefAttributes<AmityCommunityFeedRef>>>;
export default _default;
//# sourceMappingURL=AmityCommunityImageFeedComponent.d.ts.map