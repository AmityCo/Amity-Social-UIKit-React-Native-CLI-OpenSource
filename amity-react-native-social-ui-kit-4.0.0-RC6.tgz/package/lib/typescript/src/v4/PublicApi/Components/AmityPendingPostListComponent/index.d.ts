export { default } from './AmityPendingPostListComponent';
//# sourceMappingURL=index.d.ts.map