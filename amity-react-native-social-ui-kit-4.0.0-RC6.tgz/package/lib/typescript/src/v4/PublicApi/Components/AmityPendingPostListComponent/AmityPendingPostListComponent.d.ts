import React from 'react';
type PendingPostListProps = {
    community: Amity.Community;
    onPendingPostCountChange?: (count: number) => void;
};
declare const PendingPostList: ({ community, onPendingPostCountChange, }: PendingPostListProps) => React.JSX.Element;
export default PendingPostList;
//# sourceMappingURL=AmityPendingPostListComponent.d.ts.map