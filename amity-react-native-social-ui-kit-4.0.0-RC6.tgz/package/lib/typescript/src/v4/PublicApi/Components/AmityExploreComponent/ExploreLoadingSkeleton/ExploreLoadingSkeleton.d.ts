import React from 'react';
import { MyMD3Theme } from '../../../../../providers/amity-ui-kit-provider';
type ExploreLoadingSkeletonProps = {
    themeStyles: MyMD3Theme;
};
declare const _default: React.NamedExoticComponent<ExploreLoadingSkeletonProps>;
export default _default;
//# sourceMappingURL=ExploreLoadingSkeleton.d.ts.map