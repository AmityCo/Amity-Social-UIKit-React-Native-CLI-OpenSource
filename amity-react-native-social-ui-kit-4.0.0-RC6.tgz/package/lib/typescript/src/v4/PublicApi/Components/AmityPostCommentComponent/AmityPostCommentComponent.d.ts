import React from 'react';
import { UserInterface, IMentionPosition } from '../../../../types';
import { PageID } from '../../../enum';
export interface IComment {
    commentId: string;
    data: Record<string, any>;
    dataType: string | undefined;
    myReactions: string[];
    reactions: Record<string, number>;
    user: UserInterface | undefined;
    updatedAt: string | undefined;
    editedAt: string | undefined;
    createdAt: string;
    childrenComment: string[];
    referenceId: string;
    mentionees?: string[];
    mentionPosition?: IMentionPosition[];
    childrenNumber: number;
}
type AmityPostCommentComponentType = {
    pageId?: PageID;
    postId: string;
    communityId?: string;
    postType: Amity.CommentReferenceType;
    disabledInteraction?: boolean;
    setReplyUserName?: (arg: string) => void;
    setReplyCommentId?: (arg: string) => void;
    ListHeaderComponent?: JSX.Element;
};
declare const _default: React.NamedExoticComponent<AmityPostCommentComponentType>;
export default _default;
//# sourceMappingURL=AmityPostCommentComponent.d.ts.map