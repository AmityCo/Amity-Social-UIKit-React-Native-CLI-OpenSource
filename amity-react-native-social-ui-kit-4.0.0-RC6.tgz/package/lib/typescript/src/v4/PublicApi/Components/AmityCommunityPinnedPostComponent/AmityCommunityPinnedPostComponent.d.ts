import React from 'react';
type AmityCommunityPinnedPostComponentProps = {
    communityId: string;
};
declare function AmityCommunityPinnedPostComponent({ communityId, }: AmityCommunityPinnedPostComponentProps): React.JSX.Element;
export default AmityCommunityPinnedPostComponent;
//# sourceMappingURL=AmityCommunityPinnedPostComponent.d.ts.map