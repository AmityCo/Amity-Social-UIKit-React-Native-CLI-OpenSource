import React from 'react';
import { PageID } from '../../../enum';
type AmityExploreEmptyComponentProps = {
    pageId?: PageID;
};
declare const _default: React.NamedExoticComponent<AmityExploreEmptyComponentProps>;
export default _default;
//# sourceMappingURL=AmityExploreEmptyComponent.d.ts.map