import React from 'react';
import { PageID } from '../../../enum';
type AmityTrendingCommunitiesCommunityProps = {
    pageId?: PageID;
};
declare const _default: React.NamedExoticComponent<AmityTrendingCommunitiesCommunityProps>;
export default _default;
//# sourceMappingURL=AmityTrendingCommunitiesComponent.d.ts.map