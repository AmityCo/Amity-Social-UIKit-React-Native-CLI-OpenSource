import React from 'react';
import { TabName } from '../../../enum/enumTabName';
import { PageID } from '../../../enum';
type AmityCommunitySearchResultComponentType = {
    pageId?: PageID;
    searchResult: Amity.Community[] & Amity.User[];
    searchType: TabName;
    onNextPage: () => void;
};
declare const _default: React.NamedExoticComponent<AmityCommunitySearchResultComponentType>;
export default _default;
//# sourceMappingURL=AmityCommunitySearchResultComponent.d.ts.map