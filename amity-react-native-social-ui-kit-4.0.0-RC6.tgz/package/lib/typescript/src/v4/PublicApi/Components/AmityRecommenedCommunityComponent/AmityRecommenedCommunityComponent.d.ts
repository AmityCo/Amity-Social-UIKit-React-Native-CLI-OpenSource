import React from 'react';
import { ComponentID, PageID } from '../../../enum';
type AmityRecommendedCommunityComponentProps = {
    pageId?: PageID;
    componentId?: ComponentID;
};
declare const _default: React.NamedExoticComponent<AmityRecommendedCommunityComponentProps>;
export default _default;
//# sourceMappingURL=AmityRecommenedCommunityComponent.d.ts.map