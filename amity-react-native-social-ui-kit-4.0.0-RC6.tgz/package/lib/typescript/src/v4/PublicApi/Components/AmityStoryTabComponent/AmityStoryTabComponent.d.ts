import React from 'react';
import { AmityStoryTabComponentType } from '../../types';
declare const _default: React.NamedExoticComponent<AmityStoryTabComponentType>;
export default _default;
//# sourceMappingURL=AmityStoryTabComponent.d.ts.map