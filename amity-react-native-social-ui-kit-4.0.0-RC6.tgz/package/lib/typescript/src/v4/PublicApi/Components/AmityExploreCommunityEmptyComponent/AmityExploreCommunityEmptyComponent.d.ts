import React from 'react';
import { PageID } from '../../../enum';
type AmityExploreCommunityEmptyComponentProps = {
    pageId?: PageID;
};
declare const _default: React.NamedExoticComponent<AmityExploreCommunityEmptyComponentProps>;
export default _default;
//# sourceMappingURL=AmityExploreCommunityEmptyComponent.d.ts.map