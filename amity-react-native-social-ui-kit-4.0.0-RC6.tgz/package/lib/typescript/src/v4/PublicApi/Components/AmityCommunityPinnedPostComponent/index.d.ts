export { default } from './AmityCommunityPinnedPostComponent';
//# sourceMappingURL=index.d.ts.map