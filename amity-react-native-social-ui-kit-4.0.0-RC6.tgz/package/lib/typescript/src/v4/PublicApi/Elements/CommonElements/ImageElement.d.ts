import { ImageProps } from 'react-native';
import React from 'react';
import { ComponentID, ElementID, PageID, UiKitConfigKeys } from '../../../enum/enumUIKitID';
type ImageElementType = Partial<ImageProps> & {
    pageID?: PageID;
    componentID?: ComponentID;
    elementID: ElementID;
    configKey?: keyof UiKitConfigKeys;
};
declare const _default: React.NamedExoticComponent<ImageElementType>;
export default _default;
//# sourceMappingURL=ImageElement.d.ts.map