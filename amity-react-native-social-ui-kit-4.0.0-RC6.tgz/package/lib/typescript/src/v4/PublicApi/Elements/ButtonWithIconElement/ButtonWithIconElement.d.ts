import React from 'react';
import { MyMD3Theme } from 'src/providers/amity-ui-kit-provider';
import { PageID, ComponentID, ElementID } from '../../../enum';
interface ButtonWithIconElementProps {
    pageId?: PageID;
    componentId?: ComponentID;
    elementId: ElementID;
    configTheme?: MyMD3Theme;
    onClick?: () => void;
}
declare const ButtonWithIconElement: ({ pageId, componentId, elementId, onClick, }: ButtonWithIconElementProps) => React.JSX.Element;
export default ButtonWithIconElement;
//# sourceMappingURL=ButtonWithIconElement.d.ts.map