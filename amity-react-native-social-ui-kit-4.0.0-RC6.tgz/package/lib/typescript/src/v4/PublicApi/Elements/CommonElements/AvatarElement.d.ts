import { ImageProps } from 'react-native';
import { FC } from 'react';
import { ComponentID, ElementID, PageID } from '../../../enum/enumUIKitID';
type AvatarElementType = Partial<ImageProps> & {
    avatarId: string;
    pageID?: PageID;
    componentID?: ComponentID;
    elementID: ElementID;
    targetType?: 'community' | 'user';
    defaultAvatar?: string;
};
declare const AvatarElement: FC<AvatarElementType>;
export default AvatarElement;
//# sourceMappingURL=AvatarElement.d.ts.map