import { ImageProps } from 'react-native';
import React from 'react';
import { ComponentID, PageID } from '../../../enum/enumUIKitID';
type CloseButtonIconElementType = Partial<ImageProps> & {
    pageID?: PageID;
    componentID?: ComponentID;
};
declare const _default: React.NamedExoticComponent<CloseButtonIconElementType>;
export default _default;
//# sourceMappingURL=CloseButtonIconElement.d.ts.map