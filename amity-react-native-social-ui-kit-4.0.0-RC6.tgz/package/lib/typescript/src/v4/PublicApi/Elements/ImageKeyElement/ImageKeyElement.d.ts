import { ImageProps } from 'react-native';
import React from 'react';
import { ComponentID, ElementID, PageID } from '../../../enum/enumUIKitID';
type ImageKeyElementType = Partial<ImageProps> & {
    pageID?: PageID;
    componentID?: ComponentID;
    elementID?: ElementID;
};
declare const _default: React.NamedExoticComponent<ImageKeyElementType>;
export default _default;
//# sourceMappingURL=ImageKeyElement.d.ts.map