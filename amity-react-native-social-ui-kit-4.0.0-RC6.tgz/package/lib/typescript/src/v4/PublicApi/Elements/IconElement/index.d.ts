export { default as IconElement } from './IconElement';
//# sourceMappingURL=index.d.ts.map