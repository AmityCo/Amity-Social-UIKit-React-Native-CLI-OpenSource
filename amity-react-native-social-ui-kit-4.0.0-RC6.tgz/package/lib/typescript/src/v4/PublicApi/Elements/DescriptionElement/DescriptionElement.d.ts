import React from 'react';
import { TextProps } from 'react-native';
import { ComponentID, PageID } from '../../../enum/enumUIKitID';
type DescriptionElementType = Partial<TextProps> & {
    pageId?: PageID;
    componentId?: ComponentID;
};
declare const _default: React.NamedExoticComponent<DescriptionElementType>;
export default _default;
//# sourceMappingURL=DescriptionElement.d.ts.map