import { XmlProps } from 'react-native-svg';
import React from 'react';
import { ImageStyle, StyleProp } from 'react-native';
type IconElementProps = {
    defaultIcon?: string;
    configIcon?: string;
    configIconStyle?: StyleProp<ImageStyle>;
    defaultIconStyle?: Pick<XmlProps, 'width' | 'height' | 'color'>;
};
declare function IconElement({ configIcon, defaultIcon, defaultIconStyle, configIconStyle, }: IconElementProps): React.JSX.Element;
declare const _default: React.MemoExoticComponent<typeof IconElement>;
export default _default;
//# sourceMappingURL=IconElement.d.ts.map