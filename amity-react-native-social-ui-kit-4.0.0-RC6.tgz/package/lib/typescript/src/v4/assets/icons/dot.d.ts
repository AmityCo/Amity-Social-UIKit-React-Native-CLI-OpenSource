export declare const icon: (color?: string) => string;
export default icon;
//# sourceMappingURL=dot.d.ts.map