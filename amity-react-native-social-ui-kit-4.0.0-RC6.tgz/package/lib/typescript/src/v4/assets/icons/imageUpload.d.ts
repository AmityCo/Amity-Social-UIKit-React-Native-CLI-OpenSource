declare const imageUpload: () => string;
export default imageUpload;
//# sourceMappingURL=imageUpload.d.ts.map