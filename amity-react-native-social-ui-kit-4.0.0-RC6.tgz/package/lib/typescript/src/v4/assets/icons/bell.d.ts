export declare const icon: () => string;
export default icon;
//# sourceMappingURL=bell.d.ts.map