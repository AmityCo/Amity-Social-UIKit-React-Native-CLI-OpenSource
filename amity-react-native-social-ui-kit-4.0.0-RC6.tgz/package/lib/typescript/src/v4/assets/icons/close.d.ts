export declare const icon: () => string;
export default icon;
//# sourceMappingURL=close.d.ts.map