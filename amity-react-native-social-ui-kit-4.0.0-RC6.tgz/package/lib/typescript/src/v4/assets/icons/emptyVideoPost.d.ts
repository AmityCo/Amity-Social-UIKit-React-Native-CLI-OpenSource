export declare const icon: (color?: string) => string;
export default icon;
//# sourceMappingURL=emptyVideoPost.d.ts.map