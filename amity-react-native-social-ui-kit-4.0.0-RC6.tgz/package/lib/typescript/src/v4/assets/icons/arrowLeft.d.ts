export declare const icon: () => string;
export default icon;
//# sourceMappingURL=arrowLeft.d.ts.map