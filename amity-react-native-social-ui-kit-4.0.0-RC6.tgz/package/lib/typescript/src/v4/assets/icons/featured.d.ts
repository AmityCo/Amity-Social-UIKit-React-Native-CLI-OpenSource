declare const icon: ({ color, backgroundColor, }: {
    color?: string;
    backgroundColor?: string;
}) => string;
export default icon;
//# sourceMappingURL=featured.d.ts.map