export declare const icon: (color?: string) => string;
export default icon;
//# sourceMappingURL=community.d.ts.map