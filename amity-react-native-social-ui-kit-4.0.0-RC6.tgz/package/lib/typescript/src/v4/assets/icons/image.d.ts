export declare const icon: (color?: string) => string;
export default icon;
//# sourceMappingURL=image.d.ts.map