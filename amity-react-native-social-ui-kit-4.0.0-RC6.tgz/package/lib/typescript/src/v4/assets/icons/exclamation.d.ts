export declare const icon: () => string;
export default icon;
//# sourceMappingURL=exclamation.d.ts.map