declare const icon: () => string;
export default icon;
//# sourceMappingURL=demote.d.ts.map