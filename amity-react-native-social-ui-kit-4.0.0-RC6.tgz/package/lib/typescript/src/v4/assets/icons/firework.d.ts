declare const icon: () => string;
export default icon;
//# sourceMappingURL=firework.d.ts.map