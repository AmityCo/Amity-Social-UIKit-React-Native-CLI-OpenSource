export declare const checkboxUnchecked: () => string;
export declare const checkboxUncheckedDisabled: () => string;
export declare const checkboxChecked: () => string;
export declare const checkboxCheckedDisabled: () => string;
//# sourceMappingURL=checkbox.d.ts.map