export declare const icon: () => string;
export default icon;
//# sourceMappingURL=ban.d.ts.map