declare const icon: () => string;
export default icon;
//# sourceMappingURL=camera.d.ts.map