export declare const icon: (color?: string) => string;
export default icon;
//# sourceMappingURL=emptyImagePost.d.ts.map