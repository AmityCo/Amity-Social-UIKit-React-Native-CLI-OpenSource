declare const emptyList: () => string;
export default emptyList;
//# sourceMappingURL=emptyList.d.ts.map