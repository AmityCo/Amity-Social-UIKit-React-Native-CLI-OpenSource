export declare const icon: () => string;
export default icon;
//# sourceMappingURL=arrowDown.d.ts.map