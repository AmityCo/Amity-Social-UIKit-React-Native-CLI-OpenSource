export declare const icon: (color?: string) => string;
export default icon;
//# sourceMappingURL=check.d.ts.map