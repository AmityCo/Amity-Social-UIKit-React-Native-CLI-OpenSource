type IconProps = {
    backgroundColor?: string;
    itemBorderColor?: string;
    avatarColor?: string;
    titleColor?: string;
    descriptionColor?: string;
};
export declare const icon: ({ backgroundColor, itemBorderColor, avatarColor, titleColor, descriptionColor, }: IconProps) => string;
export default icon;
//# sourceMappingURL=emptyCommunity.d.ts.map