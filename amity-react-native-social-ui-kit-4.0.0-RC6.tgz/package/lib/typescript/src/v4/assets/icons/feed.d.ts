export declare const icon: (color?: string) => string;
export default icon;
//# sourceMappingURL=feed.d.ts.map