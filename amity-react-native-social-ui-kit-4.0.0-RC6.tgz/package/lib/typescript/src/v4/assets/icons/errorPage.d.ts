export declare const icon: (color?: string) => string;
export default icon;
//# sourceMappingURL=errorPage.d.ts.map