declare const icon: () => string;
export default icon;
//# sourceMappingURL=commentNotification.d.ts.map