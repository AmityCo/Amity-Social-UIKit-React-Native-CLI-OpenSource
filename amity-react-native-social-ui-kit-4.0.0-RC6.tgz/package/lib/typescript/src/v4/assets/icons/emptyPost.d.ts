export declare const icon: (color?: string) => string;
export default icon;
//# sourceMappingURL=emptyPost.d.ts.map