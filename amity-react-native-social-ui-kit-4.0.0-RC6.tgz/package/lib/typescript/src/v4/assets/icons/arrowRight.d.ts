export declare const icon: () => string;
export default icon;
//# sourceMappingURL=arrowRight.d.ts.map