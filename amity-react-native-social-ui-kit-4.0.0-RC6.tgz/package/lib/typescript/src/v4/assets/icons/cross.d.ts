export declare const icon: (color?: string) => string;
export default icon;
//# sourceMappingURL=cross.d.ts.map