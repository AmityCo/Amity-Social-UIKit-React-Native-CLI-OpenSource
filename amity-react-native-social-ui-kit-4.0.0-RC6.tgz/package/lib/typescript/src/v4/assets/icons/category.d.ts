export declare const icon: () => string;
export default icon;
//# sourceMappingURL=category.d.ts.map