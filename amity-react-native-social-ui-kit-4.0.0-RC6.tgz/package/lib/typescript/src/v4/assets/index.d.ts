export declare const defaultAvatarUri: string;
export declare const defaultCommunityAvatarUri: string;
export declare const defaultAdAvatarUri: string;
//# sourceMappingURL=index.d.ts.map