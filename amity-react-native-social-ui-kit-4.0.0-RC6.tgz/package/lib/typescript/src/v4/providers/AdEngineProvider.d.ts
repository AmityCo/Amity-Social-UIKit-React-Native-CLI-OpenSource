import React, { PropsWithChildren } from 'react';
export declare const AdEngineContext: React.Context<{
    ads: Amity.Ad[];
    settings: Amity.AdsSettings | null;
    isLoading: boolean;
    saveItemsPagination: (data: {
        targetId?: string;
        placement: string;
        frequencyType: string;
        adId: string;
        referenceId: string;
    }) => void;
    getItemsPaginationCache: (data: {
        targetId?: string;
        frequencyType: string;
        placement: string;
    }) => {
        adId: string;
        referenceId: string;
    }[] | undefined;
}>;
export declare const AdEngineProvider: React.FC<PropsWithChildren>;
export declare const useAds: () => Amity.Ad[];
export declare const useAdSettings: () => Amity.AdsSettings;
export declare const useRecommendAds: ({ count, placement, communityId, }: {
    count: number;
    placement: Amity.AdPlacement;
    communityId?: string;
}) => {
    resetRecommendedAds: () => void;
    recommendedAds: Amity.Ad[];
};
//# sourceMappingURL=AdEngineProvider.d.ts.map