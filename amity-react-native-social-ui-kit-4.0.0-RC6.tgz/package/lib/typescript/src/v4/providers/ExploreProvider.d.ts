import React, { ReactNode } from 'react';
interface ExploreContextType {
    refresh: () => void;
    onJoinRecommendedCommunity: (communityId: string) => void;
    recommendedCommunities: Amity.Community[];
    trendingCommunities: Amity.Community[];
    categories: Amity.Category[];
    isCategoryEmpty: boolean;
    isRecommendedCommunitiesEmpty: boolean;
    isTrendingCommunitiesEmpty: boolean;
    isLoading: boolean;
    isAllError: boolean;
    isAllCommunitiesError: boolean;
    hasMoreCategories: boolean;
}
export declare const ExploreProvider: React.FC<{
    children: ReactNode;
}>;
export declare const useExplore: () => ExploreContextType;
export {};
//# sourceMappingURL=ExploreProvider.d.ts.map