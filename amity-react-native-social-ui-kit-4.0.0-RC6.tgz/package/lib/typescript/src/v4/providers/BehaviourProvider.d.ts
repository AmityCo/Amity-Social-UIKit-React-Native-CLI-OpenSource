import React, { ReactNode } from 'react';
import { IBehaviour } from '../types/behaviour.interface';
interface IBehavioudProviderProps {
    children: ReactNode;
    behaviour: IBehaviour;
}
export declare const BehaviourProvider: ({ children, behaviour, }: IBehavioudProviderProps) => React.JSX.Element;
export declare const useBehaviour: () => IBehaviour;
export {};
//# sourceMappingURL=BehaviourProvider.d.ts.map