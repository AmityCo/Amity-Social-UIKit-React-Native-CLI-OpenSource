import React from 'react';
import { TSearchItem } from '..';
import { StyleProp, TextInputProps, ViewStyle } from 'react-native';
import { IMentionPosition } from '../../../types';
type UseMentionProps = {
    value: string;
    communityId?: string;
    onChange: (value: string) => void;
    setMentionPosition: (position: IMentionPosition) => void;
    setMentionUsers: (user: TSearchItem) => void;
};
type RenderSuggestionsProps = {
    type?: 'post' | 'comment';
    style?: StyleProp<ViewStyle>;
    bottom?: number;
};
declare function useMention({ value, onChange, communityId, setMentionUsers, setMentionPosition, }: UseMentionProps): {
    renderInput: (props: TextInputProps) => React.JSX.Element;
    renderSuggestions: ({ type, style, bottom, }: RenderSuggestionsProps) => React.JSX.Element;
};
export default useMention;
//# sourceMappingURL=index.d.ts.map