export declare enum AmityCommunityPrivacyEnum {
    PUBLIC = "public",
    PRIVATE = "private"
}
//# sourceMappingURL=index.d.ts.map