import React from 'react';
type MembersProps = {
    value: Amity.User[];
    goBack: () => void;
    onChange: (users: Amity.User[]) => void;
};
declare function Members({ value, goBack, onChange }: MembersProps): React.JSX.Element;
export default Members;
//# sourceMappingURL=index.d.ts.map