import React from 'react';
import { UseImagePickerResponse } from '../../../../../../v4/hook/useImagePicker';
type CoverImageUploadProps = Pick<UseImagePickerResponse, 'openCamera' | 'openImageGallery' | 'progress'> & {
    value: Amity.File<'image'>;
    onChange: (file: Amity.File<'image'> | null) => void;
};
declare function CoverImageUpload({ value, progress, onChange, openCamera, openImageGallery, }: CoverImageUploadProps): React.JSX.Element;
export default CoverImageUpload;
//# sourceMappingURL=index.d.ts.map