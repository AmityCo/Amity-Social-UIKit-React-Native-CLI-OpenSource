import React from 'react';
type HeaderProps = {
    onSave: () => void;
    disabled?: boolean;
};
declare function Header({ onSave, disabled }: HeaderProps): React.JSX.Element;
export default Header;
//# sourceMappingURL=Header.d.ts.map