export { default } from './CloseCommunity';
//# sourceMappingURL=index.d.ts.map