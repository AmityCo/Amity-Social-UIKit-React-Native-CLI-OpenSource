export { default } from './PostPermission';
//# sourceMappingURL=index.d.ts.map