import React from 'react';
declare const AddCategory: () => React.JSX.Element;
export default AddCategory;
//# sourceMappingURL=AddCategory.d.ts.map