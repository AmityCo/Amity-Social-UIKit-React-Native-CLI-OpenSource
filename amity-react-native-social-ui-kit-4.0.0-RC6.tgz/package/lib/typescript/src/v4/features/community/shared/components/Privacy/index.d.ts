import React from 'react';
import { AmityCommunityPrivacyEnum } from '../../types';
type PrivacyProps = {
    value: AmityCommunityPrivacyEnum;
    onChange: (value: AmityCommunityPrivacyEnum) => void;
};
declare function Privacy({ value, onChange }: PrivacyProps): React.JSX.Element;
export default Privacy;
//# sourceMappingURL=index.d.ts.map