export { default } from './AddCategory';
//# sourceMappingURL=index.d.ts.map