import React from 'react';
type HeaderProps = {
    count: number;
    total: number;
    bordered?: boolean;
};
declare function Header({ count, total, bordered }: HeaderProps): React.JSX.Element;
export default Header;
//# sourceMappingURL=Header.d.ts.map