import React from 'react';
declare const AddMember: () => React.JSX.Element;
export default AddMember;
//# sourceMappingURL=AddMember.d.ts.map