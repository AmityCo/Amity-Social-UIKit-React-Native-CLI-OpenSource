export { default } from './Create';
//# sourceMappingURL=index.d.ts.map