export { default } from './LeaveCommunity';
//# sourceMappingURL=index.d.ts.map