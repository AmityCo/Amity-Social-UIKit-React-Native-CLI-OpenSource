export { default } from './ModeratorList';
//# sourceMappingURL=index.d.ts.map