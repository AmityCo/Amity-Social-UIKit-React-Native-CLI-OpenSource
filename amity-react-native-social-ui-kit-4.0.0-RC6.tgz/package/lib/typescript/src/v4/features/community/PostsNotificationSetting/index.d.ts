export { default } from './PostsNotificationSetting';
//# sourceMappingURL=index.d.ts.map