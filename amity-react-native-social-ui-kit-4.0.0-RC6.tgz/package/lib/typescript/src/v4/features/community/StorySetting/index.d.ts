export { default } from './StorySetting';
//# sourceMappingURL=index.d.ts.map