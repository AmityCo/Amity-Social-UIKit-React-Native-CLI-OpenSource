export { default } from './Setting';
//# sourceMappingURL=index.d.ts.map