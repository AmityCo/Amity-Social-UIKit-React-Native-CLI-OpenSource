export { default } from './CloseCommunityDescription';
//# sourceMappingURL=index.d.ts.map