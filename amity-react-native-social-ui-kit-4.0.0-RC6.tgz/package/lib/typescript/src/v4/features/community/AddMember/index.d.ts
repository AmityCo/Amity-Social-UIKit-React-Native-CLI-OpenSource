export { default } from './AddMember';
//# sourceMappingURL=index.d.ts.map