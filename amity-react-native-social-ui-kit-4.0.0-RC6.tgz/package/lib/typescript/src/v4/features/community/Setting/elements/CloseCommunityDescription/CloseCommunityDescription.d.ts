import React from 'react';
import { TouchableOpacityProps } from 'react-native';
import { ComponentID, ElementID, PageID } from '../../../../../../v4/enum';
type CloseCommunityDescriptionProps = TouchableOpacityProps & {
    pageId?: PageID;
    componentId?: ComponentID;
    elementId?: ElementID;
};
declare function CloseCommunityDescription({ pageId, componentId, elementId, ...props }: CloseCommunityDescriptionProps): React.JSX.Element;
export default CloseCommunityDescription;
//# sourceMappingURL=CloseCommunityDescription.d.ts.map