export { default } from './CommentsNotificationSetting';
//# sourceMappingURL=index.d.ts.map