import React from 'react';
type HeaderProps = {
    isFormDirty: boolean;
};
declare function Header({ isFormDirty }: HeaderProps): React.JSX.Element;
export default Header;
//# sourceMappingURL=Header.d.ts.map