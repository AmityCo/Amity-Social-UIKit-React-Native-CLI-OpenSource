export { default } from './Edit';
//# sourceMappingURL=index.d.ts.map