import React from 'react';
type CategoriesProps = {
    categories: Amity.Category[];
    goBack: () => void;
    onChange: (categories: Amity.Category[]) => void;
};
declare function Categories({ onChange, categories, goBack }: CategoriesProps): React.JSX.Element;
export default Categories;
//# sourceMappingURL=index.d.ts.map