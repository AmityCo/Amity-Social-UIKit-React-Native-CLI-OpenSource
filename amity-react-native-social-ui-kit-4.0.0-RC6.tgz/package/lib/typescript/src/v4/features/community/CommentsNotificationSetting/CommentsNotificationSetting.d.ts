import React from 'react';
type CommunityCommentsNotificationSettingProps = {
    community: Amity.Community;
};
declare const CommunityCommentsNotificationSetting: ({ community, }: CommunityCommentsNotificationSettingProps) => React.JSX.Element;
export default CommunityCommentsNotificationSetting;
//# sourceMappingURL=CommentsNotificationSetting.d.ts.map