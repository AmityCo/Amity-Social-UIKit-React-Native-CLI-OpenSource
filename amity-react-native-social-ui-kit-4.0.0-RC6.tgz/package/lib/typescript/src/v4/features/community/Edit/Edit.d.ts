import React from 'react';
type EditCommunity = {
    community: Amity.Community;
};
declare function EditCommunity({ community }: EditCommunity): React.JSX.Element;
export default EditCommunity;
//# sourceMappingURL=Edit.d.ts.map