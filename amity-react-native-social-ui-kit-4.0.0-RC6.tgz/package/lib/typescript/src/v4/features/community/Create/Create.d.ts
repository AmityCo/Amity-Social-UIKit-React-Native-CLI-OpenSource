import React from 'react';
declare function CreateCommunity(): React.JSX.Element;
export default CreateCommunity;
//# sourceMappingURL=Create.d.ts.map