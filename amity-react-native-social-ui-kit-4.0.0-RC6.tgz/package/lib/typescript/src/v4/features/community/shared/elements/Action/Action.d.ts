import React from 'react';
import { XmlProps } from 'react-native-svg';
import { ComponentID, ElementID, PageID } from '../../../../../../v4/enum';
import { TouchableOpacityProps } from 'react-native';
type ActionProps = TouchableOpacityProps & {
    pageId?: PageID;
    componentId?: ComponentID;
    elementId?: ElementID;
    iconProps?: Pick<XmlProps, 'width' | 'height' | 'color' | 'xml'> & {
        noContainer?: boolean;
    };
    description?: string;
    label?: string;
};
declare function Action({ iconProps, description, pageId, componentId, elementId, label, ...props }: ActionProps): React.JSX.Element;
export default Action;
//# sourceMappingURL=Action.d.ts.map