import React from 'react';
type HeaderProps = {
    title: string;
};
declare function Header({ title }: HeaderProps): React.JSX.Element;
export default Header;
//# sourceMappingURL=Header.d.ts.map