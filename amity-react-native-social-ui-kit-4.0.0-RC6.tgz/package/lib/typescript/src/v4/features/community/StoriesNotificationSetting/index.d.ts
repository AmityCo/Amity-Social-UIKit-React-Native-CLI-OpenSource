export { default } from './StoriesNotificationSetting';
//# sourceMappingURL=index.d.ts.map