import React from 'react';
type HeaderProps = {
    onSave: () => void;
    disabled?: boolean;
    isFormDirty: boolean;
};
declare function Header({ onSave, disabled, isFormDirty }: HeaderProps): React.JSX.Element;
export default Header;
//# sourceMappingURL=Header.d.ts.map