export { default } from './NotificationSetting';
//# sourceMappingURL=index.d.ts.map