import React from 'react';
type HeaderProps = {
    onAddMember: (users: Amity.User[]) => void;
};
declare function Header({ onAddMember }: HeaderProps): React.JSX.Element;
export default Header;
//# sourceMappingURL=Header.d.ts.map