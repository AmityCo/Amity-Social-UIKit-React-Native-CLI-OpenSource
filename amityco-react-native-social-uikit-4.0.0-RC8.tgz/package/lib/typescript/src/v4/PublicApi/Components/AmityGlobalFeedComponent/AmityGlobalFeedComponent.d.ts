import React from 'react';
import { PageID } from '../../../enum/enumUIKitID';
type AmityGlobalFeedComponentType = {
    pageId?: PageID;
    isShowStoryTab?: boolean;
};
export declare const globalFeedPageLimit = 20;
declare const _default: React.NamedExoticComponent<AmityGlobalFeedComponentType>;
export default _default;
//# sourceMappingURL=AmityGlobalFeedComponent.d.ts.map