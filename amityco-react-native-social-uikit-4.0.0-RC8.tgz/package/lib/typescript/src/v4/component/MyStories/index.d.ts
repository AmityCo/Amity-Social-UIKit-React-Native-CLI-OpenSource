import React from 'react';
export interface IStoryItems {
    communityId: string;
    avatarFileId: string;
    displayName: string;
    isPublic: boolean;
    isOfficial: boolean;
    hasStories: boolean;
}
export declare const AmityGlobalStoryTabWrapper: ({ children }: {
    children: any;
}) => React.JSX.Element;
declare const _default: React.MemoExoticComponent<() => React.JSX.Element>;
export default _default;
//# sourceMappingURL=index.d.ts.map